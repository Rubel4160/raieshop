"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { SlidersHorizontal } from "lucide-react";

type Option = { name: string; slug: string };

export default function ShopFilters({
  categories,
  subcategories,
}: {
  categories: Option[];
  subcategories: (Option & { categorySlug: string })[];
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [search, setSearch] = useState(params.get("search") ?? "");
  const [category, setCategory] = useState(params.get("category") ?? "");
  const [sub, setSub] = useState(params.get("sub") ?? "");

  useEffect(() => {
    setSearch(params.get("search") ?? "");
    setCategory(params.get("category") ?? "");
    setSub(params.get("sub") ?? "");
  }, [params]);

  const visibleSubs = category
    ? subcategories.filter((s) => s.categorySlug === category)
    : subcategories;

  const apply = () => {
    const p = new URLSearchParams();
    if (search.trim()) p.set("search", search.trim());
    if (category) p.set("category", category);
    if (sub) p.set("sub", sub);
    router.push(`/shop${p.size ? `?${p.toString()}` : ""}`);
  };

  const reset = () => {
    setSearch("");
    setCategory("");
    setSub("");
    router.push("/shop");
  };

  const selectCls =
    "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-700 outline-none transition focus:border-navy-900";

  return (
    <aside className="h-fit rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-100 lg:sticky lg:top-40">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-extrabold text-slate-900">Filter Products</h3>
          <p className="mt-1 max-w-[180px] text-[12px] leading-snug text-slate-500">
            Find your ideal product faster.
          </p>
        </div>
        <span className="flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-[10px] font-bold text-amber-700">
          <SlidersHorizontal size={11} />
          Filter
        </span>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
            Search
          </label>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && apply()}
            placeholder="Search product..."
            className={selectCls}
          />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
            Category
          </label>
          <select
            value={category}
            onChange={(e) => {
              setCategory(e.target.value);
              setSub("");
            }}
            className={selectCls}
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.slug} value={c.slug}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
            Subcategory
          </label>
          <select value={sub} onChange={(e) => setSub(e.target.value)} className={selectCls}>
            <option value="">All Subcategories</option>
            {visibleSubs.map((s) => (
              <option key={s.slug} value={s.slug}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <button
          onClick={apply}
          className="w-full rounded-full bg-navy-900 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800"
        >
          Apply Filter
        </button>
        <button
          onClick={reset}
          className="w-full rounded-full border border-slate-200 py-2.5 text-sm font-bold text-slate-500 transition hover:border-slate-300 hover:text-slate-700"
        >
          Reset
        </button>
      </div>
    </aside>
  );
}
