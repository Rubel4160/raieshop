import Link from "next/link";
import { taka, discountPercent } from "@/lib/site";
import type { ProductCard } from "@/lib/data";
import { AddToCartButton, WishlistHeart } from "./Buttons";

export function Price({
  price,
  salePrice,
  className = "",
}: {
  price: number;
  salePrice: number | null;
  className?: string;
}) {
  return (
    <span className={`flex flex-wrap items-baseline gap-1.5 ${className}`}>
      {salePrice ? (
        <span className="text-[13px] font-semibold text-slate-400 line-through">
          {taka(price)}
        </span>
      ) : null}
      <span className="text-lg font-extrabold text-blue-600">
        {taka(salePrice ?? price)}
      </span>
    </span>
  );
}

export function StockLabel({ stock }: { stock: number }) {
  return stock > 0 ? (
    <span className="text-[12px] font-semibold text-emerald-600">
      <span className="mr-1 text-slate-400">Stock</span>
      {stock} pcs
    </span>
  ) : (
    <span className="text-[12px] font-semibold text-red-500">
      <span className="mr-1 text-slate-400">Stock</span>
      Unavailable
    </span>
  );
}

/** Full card used on /shop */
export function ShopProductCard({ product }: { product: ProductCard }) {
  const off = discountPercent(product.price, product.salePrice);
  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200">
      <div className="relative">
        <Link href={`/product/${product.slug}`} className="block aspect-[4/3] overflow-hidden bg-slate-50">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        </Link>
        <div className="absolute inset-x-3 top-3 flex items-center justify-between">
          <div className="flex gap-1.5">
            {product.isFeatured && (
              <span className="rounded-full bg-navy-900 px-2.5 py-1 text-[10px] font-bold text-white">
                Featured
              </span>
            )}
            {off > 0 && (
              <span className="rounded-full bg-red-500 px-2.5 py-1 text-[10px] font-bold text-white">
                Sale
              </span>
            )}
          </div>
          {product.stock > 0 ? (
            <span className="rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold text-emerald-600 shadow-sm">
              In Stock
            </span>
          ) : (
            <span className="rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold text-red-500 shadow-sm">
              Out of Stock
            </span>
          )}
        </div>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center justify-between">
          <span className="rounded-md bg-blue-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-blue-600">
            {product.category}
          </span>
          <span className="text-[11px] text-slate-400">{product.subcategory ?? ""}</span>
        </div>
        <Link
          href={`/product/${product.slug}`}
          className="mt-2 text-[15px] font-bold text-slate-900 hover:text-orange-600"
        >
          {product.name}
        </Link>
        <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-slate-500">
          {product.description}
        </p>

        <div className="mt-auto pt-3">
          <div className="flex items-end justify-between">
            <Price price={product.price} salePrice={product.salePrice} />
            <StockLabel stock={product.stock} />
          </div>
          <div className="mt-3 flex items-center gap-2">
            <Link
              href={`/product/${product.slug}`}
              className="flex-1 rounded-full border border-slate-200 py-2 text-center text-[13px] font-bold text-slate-700 transition hover:border-navy-900 hover:text-navy-900"
            >
              View Product
            </Link>
            <WishlistHeart product={product} />
          </div>
          <div className="mt-2">
            <AddToCartButton product={product} />
          </div>
        </div>
      </div>
    </div>
  );
}

/** Card used on /flash-sale page */
export function FlashProductCard({ product }: { product: ProductCard }) {
  const off = discountPercent(product.price, product.salePrice);
  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-red-100">
      <div className="relative">
        <Link href={`/product/${product.slug}`} className="block aspect-[4/3] overflow-hidden bg-slate-50">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        </Link>
        {off > 0 && (
          <span className="absolute left-3 top-3 rounded-full bg-red-500 px-2.5 py-1 text-[10px] font-bold text-white shadow-lg">
            {off}% OFF
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col p-4">
        <span className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
          {product.category}
        </span>
        <Link
          href={`/product/${product.slug}`}
          className="mt-1 text-[15px] font-bold text-slate-900 hover:text-red-600"
        >
          {product.name}
        </Link>
        <p className="mt-1 line-clamp-2 text-[12.5px] leading-relaxed text-slate-500">
          {product.description}
        </p>
        <div className="mt-auto pt-3">
          <span className="flex flex-wrap items-baseline gap-1.5">
            <span className="text-[13px] font-semibold text-slate-400 line-through">
              {taka(product.price)}
            </span>
            <span className="text-xl font-extrabold text-red-600">
              {taka(product.salePrice ?? product.price)}
            </span>
          </span>
          {(product.salePrice ?? 0) > 0 && (
            <p className="mt-0.5 text-[12px] font-semibold text-emerald-600">
              You save {taka(product.price - (product.salePrice ?? 0))}
            </p>
          )}
          {product.stock > 0 ? (
            <p className="mt-1 text-[12px] font-semibold text-slate-600">
              Stock Left: {product.stock}
            </p>
          ) : (
            <p className="mt-1 text-[12px] font-semibold text-red-500">Stock unavailable</p>
          )}
          <div className="mt-3 space-y-2">
            <Link
              href={`/product/${product.slug}`}
              className="block w-full rounded-full border border-slate-200 py-2 text-center text-[13px] font-bold text-slate-700 transition hover:border-navy-900 hover:text-navy-900"
            >
              View Product
            </Link>
            <AddToCartButton product={product} variant="red" />
          </div>
        </div>
      </div>
    </div>
  );
}

/** Compact card used in home hero + lifestyle panels */
export function MiniProductCard({
  product,
  cta = "View Product",
}: {
  product: ProductCard;
  cta?: string;
}) {
  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-xl bg-white ring-1 ring-slate-100 transition hover:shadow-lg hover:shadow-slate-200">
      <Link href={`/product/${product.slug}`} className="block aspect-[16/10] overflow-hidden bg-slate-50">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      </Link>
      <div className="flex flex-1 flex-col p-3">
        <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-400">
          {product.category}
        </span>
        <Link
          href={`/product/${product.slug}`}
          className="mt-0.5 truncate text-[13.5px] font-bold text-slate-900 hover:text-orange-600"
        >
          {product.name}
        </Link>
        <div className="mt-auto pt-2">
          <Price price={product.price} salePrice={product.salePrice} className="[&>span]:text-[15px] [&>span:first-child]:text-[11.5px]" />
          <Link
            href={`/product/${product.slug}`}
            className="mt-2 block rounded-full bg-navy-900 py-1.5 text-center text-[11.5px] font-bold text-white transition hover:bg-navy-800"
          >
            {cta}
          </Link>
        </div>
      </div>
    </div>
  );
}

/** Card used in Best Sellers */
export function BestSellerCard({ product }: { product: ProductCard }) {
  return (
    <div className="group overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200">
      <Link href={`/product/${product.slug}`} className="block aspect-[16/10] overflow-hidden bg-slate-50">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      </Link>
      <div className="p-4">
        <span className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
          {product.category}
        </span>
        <Link
          href={`/product/${product.slug}`}
          className="mt-0.5 block text-[15px] font-bold text-slate-900 hover:text-orange-600"
        >
          {product.name}
        </Link>
        <div className="mt-1.5">
          <Price price={product.price} salePrice={product.salePrice} />
        </div>
        <Link
          href={`/product/${product.slug}`}
          className="mt-3 block rounded-full border border-slate-300 py-2 text-center text-[13px] font-bold text-slate-700 transition hover:border-navy-900 hover:bg-navy-900 hover:text-white"
        >
          Explore
        </Link>
      </div>
    </div>
  );
}
