"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error();
      setState("done");
      setEmail("");
    } catch {
      setState("error");
    }
  };

  return (
    <div>
      <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          className="h-11 flex-1 rounded-full border border-slate-200 bg-white px-5 text-sm outline-none transition focus:border-orange-400 focus:ring-2 focus:ring-orange-100"
        />
        <button
          disabled={state === "loading"}
          className="h-11 rounded-full bg-orange-500 px-7 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600 disabled:opacity-60"
        >
          {state === "loading" ? "Subscribing..." : "Subscribe"}
        </button>
      </form>
      {state === "done" && (
        <p className="mt-3 text-[12.5px] font-semibold text-emerald-600">
          Thanks for subscribing! Offers will reach your inbox soon.
        </p>
      )}
      {state === "error" && (
        <p className="mt-3 text-[12.5px] font-semibold text-red-500">
          Something went wrong. Please try again.
        </p>
      )}
    </div>
  );
}
