"use client";

import { useState } from "react";
import { Minus, Plus, ShoppingCart, Zap } from "lucide-react";
import { useRouter } from "next/navigation";
import { useStore } from "@/context/StoreContext";
import type { ProductCard } from "@/lib/data";

export default function PDPOptions({ product }: { product: ProductCard }) {
  const router = useRouter();
  const { addToCart } = useStore();
  const sizes = product.sizes ? product.sizes.split(",").filter(Boolean) : [];
  const colors = product.colors ? product.colors.split(",").filter(Boolean) : [];
  const [size, setSize] = useState(sizes[0] ?? "");
  const [color, setColor] = useState(colors[0] ?? "");
  const [qty, setQty] = useState(1);

  const variant = [size && `Size: ${size}`, color && `Color: ${color}`]
    .filter(Boolean)
    .join(" / ");

  const payload = {
    id: product.id,
    slug: product.slug,
    name: product.name,
    image: product.image,
    price: product.salePrice ?? product.price,
    variant,
  };

  const chip = (active: boolean) =>
    `rounded-full border px-4 py-1.5 text-[12.5px] font-bold transition ${
      active
        ? "border-navy-900 bg-navy-900 text-white"
        : "border-slate-200 bg-white text-slate-600 hover:border-slate-400"
    }`;

  const disabled = product.stock <= 0;

  return (
    <div className="mt-6 space-y-5">
      {sizes.length > 0 && (
        <div>
          <p className="mb-2 text-[12.5px] font-bold text-slate-700">
            Size <span className="ml-1 font-semibold text-slate-400">{size}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {sizes.map((s) => (
              <button key={s} onClick={() => setSize(s)} className={chip(size === s)}>
                {s}
              </button>
            ))}
          </div>
        </div>
      )}
      {colors.length > 0 && (
        <div>
          <p className="mb-2 text-[12.5px] font-bold text-slate-700">
            Color <span className="ml-1 font-semibold text-slate-400">{color}</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {colors.map((c) => (
              <button key={c} onClick={() => setColor(c)} className={chip(color === c)}>
                {c}
              </button>
            ))}
          </div>
        </div>
      )}

      <div>
        <p className="mb-2 text-[12.5px] font-bold text-slate-700">Quantity</p>
        <div className="inline-flex items-center rounded-full border border-slate-200 bg-white">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="px-4 py-2 text-slate-500 hover:text-navy-900"
            aria-label="Decrease"
          >
            <Minus size={14} />
          </button>
          <span className="min-w-10 text-center text-sm font-bold">{qty}</span>
          <button
            onClick={() => setQty((q) => Math.min(product.stock || 99, q + 1))}
            className="px-4 py-2 text-slate-500 hover:text-navy-900"
            aria-label="Increase"
          >
            <Plus size={14} />
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <button
          disabled={disabled}
          onClick={() => addToCart(payload, qty)}
          className="flex flex-1 items-center justify-center gap-2 rounded-full bg-navy-900 py-3 text-sm font-bold text-white transition hover:bg-navy-800 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400"
        >
          <ShoppingCart size={16} />
          {disabled ? "Out of Stock" : "Add to Cart"}
        </button>
        <button
          disabled={disabled}
          onClick={() => {
            addToCart(payload, qty);
            router.push("/checkout");
          }}
          className="flex flex-1 items-center justify-center gap-2 rounded-full bg-orange-500 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
        >
          <Zap size={16} className="fill-white" />
          Buy Now
        </button>
      </div>
    </div>
  );
}
