import Link from "next/link";
import { Headset } from "lucide-react";
import { SITE } from "@/lib/site";

const quickLinks = [
  { label: "Home", href: "/" },
  { label: "Shop", href: "/shop" },
  { label: "Cart", href: "/cart" },
  { label: "Checkout", href: "/checkout" },
  { label: "Track Order", href: "/track-order" },
  { label: "Contact", href: "/pages/contact" },
];

const policyLinks = [
  { label: "About Us", href: "/pages/about-us" },
  { label: "FAQ", href: "/pages/faq" },
  { label: "Privacy Policy", href: "/pages/privacy-policy" },
  { label: "Return & Refund", href: "/pages/return-refund" },
  { label: "Shipping Policy", href: "/pages/shipping-policy" },
  { label: "Terms & Conditions", href: "/pages/terms-conditions" },
];

const support = [
  "Fast Order Processing",
  "Easy Order Tracking",
  "Secure Checkout Flow",
  "Invoice Support",
  "Facebook Messenger",
  "WhatsApp Support",
];

const payment = [
  "Cash on Delivery",
  "Manual bKash Payment",
  "Manual Nagad Payment",
  "Inside Dhaka Delivery",
  "Outside Dhaka Delivery",
];

export default function Footer() {
  return (
    <footer className="mt-16 bg-navy-900 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 pt-14">
        {/* CTA */}
        <div className="rounded-2xl border border-white/10 bg-white/[0.04] px-6 py-10 text-center shadow-2xl shadow-black/20">
          <h2 className="text-2xl font-extrabold text-white sm:text-3xl">
            Ready to Start Shopping?
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            Browse premium products and place your order today.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/shop"
              className="rounded-full bg-orange-500 px-7 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-600/30 transition hover:bg-orange-600"
            >
              Shop Now
            </Link>
            <Link
              href="/track-order"
              className="rounded-full border border-white/20 px-7 py-2.5 text-sm font-bold text-slate-200 transition hover:bg-white/10"
            >
              Track Order
            </Link>
            <Link
              href="/pages/contact"
              className="rounded-full bg-white px-7 py-2.5 text-sm font-bold text-navy-900 transition hover:bg-slate-100"
            >
              Contact Us
            </Link>
          </div>
        </div>

        {/* columns */}
        <div className="grid grid-cols-2 gap-10 py-14 md:grid-cols-3 lg:grid-cols-5">
          <div className="col-span-2 md:col-span-1">
            <p className="text-lg font-extrabold text-white">{SITE.name}</p>
            <p className="mt-3 text-[13px] leading-relaxed text-slate-400">
              {SITE.tagline}
            </p>
            <div className="mt-4 space-y-1.5 text-[13px]">
              <p>
                <span className="font-bold text-white">Phone:</span>{" "}
                <span className="text-slate-400">{SITE.phone.replace("+88", "")}</span>
              </p>
              <p>
                <span className="font-bold text-white">Email:</span>{" "}
                <span className="text-slate-400">{SITE.email}</span>
              </p>
              <p>
                <span className="font-bold text-white">Address:</span>{" "}
                <span className="text-slate-400">{SITE.address}</span>
              </p>
            </div>
          </div>

          <div>
            <p className="text-sm font-bold text-white">Quick Links</p>
            <ul className="mt-3 space-y-2 text-[13px]">
              {quickLinks.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="text-slate-400 transition hover:text-orange-400">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-bold text-white">Policy Links</p>
            <ul className="mt-3 space-y-2 text-[13px]">
              {policyLinks.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="text-slate-400 transition hover:text-orange-400">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-bold text-white">Support</p>
            <ul className="mt-3 space-y-2 text-[13px] text-slate-400">
              {support.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-bold text-white">Payment &amp; Delivery</p>
            <ul className="mt-3 space-y-2 text-[13px] text-slate-400">
              {payment.map((s) => (
                <li key={s}>{s}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-[12.5px] text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} {SITE.name}. All rights reserved.</p>
          <p>{SITE.tagline}</p>
        </div>
      </div>

      {/* floating support */}
      <a
        href={`https://wa.me/${SITE.phoneRaw}`}
        target="_blank"
        rel="noreferrer"
        aria-label="Support"
        className="fixed bottom-6 right-6 z-[80] flex h-12 w-12 items-center justify-center rounded-full bg-navy-800 text-amber-400 shadow-2xl ring-1 ring-white/15 transition hover:scale-105"
      >
        <Headset size={20} />
      </a>
    </footer>
  );
}
