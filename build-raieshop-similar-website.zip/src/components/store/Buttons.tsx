"use client";

import Link from "next/link";
import { Heart } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import type { ProductCard } from "@/lib/data";

export function wishlistSnapshot(p: ProductCard) {
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    image: p.image,
    price: p.price,
    salePrice: p.salePrice,
    category: p.category,
    stock: p.stock,
  };
}

export function WishlistHeart({
  product,
  className = "",
}: {
  product: ProductCard;
  className?: string;
}) {
  const { toggleWishlist, isWishlisted } = useStore();
  const active = isWishlisted(product.id);
  return (
    <button
      onClick={() => toggleWishlist(wishlistSnapshot(product))}
      aria-label="Toggle wishlist"
      className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full border transition ${
        active
          ? "border-rose-200 bg-rose-50 text-rose-500"
          : "border-slate-200 bg-white text-slate-500 hover:border-rose-200 hover:text-rose-500"
      } ${className}`}
    >
      <Heart size={16} className={active ? "fill-rose-500" : ""} />
    </button>
  );
}

export function AddToCartButton({
  product,
  variant = "dark",
  label,
}: {
  product: ProductCard;
  variant?: "dark" | "red";
  label?: string;
}) {
  const { addToCart } = useStore();
  const price = product.salePrice ?? product.price;

  if (product.stock <= 0) {
    return (
      <button
        disabled
        className="w-full cursor-not-allowed rounded-full bg-slate-100 py-2.5 text-sm font-bold text-slate-400"
      >
        Out of Stock
      </button>
    );
  }

  if (product.hasOptions) {
    return (
      <div>
        <Link
          href={`/product/${product.slug}`}
          className={`block w-full rounded-full py-2.5 text-center text-sm font-bold text-white transition ${
            variant === "red"
              ? "bg-red-600 hover:bg-red-500"
              : "bg-navy-900 hover:bg-navy-800"
          }`}
        >
          Select Options
        </Link>
        <p className="mt-1.5 text-center text-[11px] text-slate-400">
          Choose size/color before adding to cart
        </p>
      </div>
    );
  }

  return (
    <button
      onClick={() =>
        addToCart({
          id: product.id,
          slug: product.slug,
          name: product.name,
          image: product.image,
          price,
          variant: "",
        })
      }
      className={`w-full rounded-full py-2.5 text-sm font-bold text-white transition ${
        variant === "red"
          ? "bg-red-600 hover:bg-red-500"
          : "bg-navy-900 hover:bg-navy-800"
      }`}
    >
      {label ?? "Add to Cart"}
    </button>
  );
}
