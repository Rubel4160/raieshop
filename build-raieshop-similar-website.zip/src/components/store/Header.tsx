"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  Flame,
  Heart,
  Menu,
  PackageSearch,
  Search,
  ShoppingCart,
  User,
  X,
} from "lucide-react";
import { SITE, TICKER_ITEMS } from "@/lib/site";
import { useStore } from "@/context/StoreContext";

type NavCat = {
  name: string;
  slug: string;
  subs: { name: string; slug: string }[];
};

function Ticker() {
  const row = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div className="overflow-hidden bg-navy-950 py-2 text-[11px] font-semibold text-slate-300">
      <div className="animate-marquee flex w-max items-center gap-6 whitespace-nowrap">
        {row.map((item, i) => (
          <span key={i} className="flex items-center gap-6">
            <span>{item}</span>
            <span className="h-1 w-1 rounded-full bg-amber-400" />
          </span>
        ))}
      </div>
    </div>
  );
}

function Logo() {
  return (
    <Link href="/" className="flex shrink-0 items-center gap-2.5">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-lg font-black text-white shadow-lg shadow-fuchsia-900/40">
        RS
      </span>
      <span className="text-xl font-extrabold tracking-tight text-white">
        <span className="bg-gradient-to-r from-violet-300 to-fuchsia-300 bg-clip-text text-transparent">
          RAIE
        </span>
        <span className="text-white">SHOP</span>
      </span>
    </Link>
  );
}

export default function Header({ categories }: { categories: NavCat[] }) {
  const router = useRouter();
  const pathname = usePathname();
  const { cartCount, wishlist } = useStore();
  const [q, setQ] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const [accOpen, setAccOpen] = useState(false);
  const catRef = useRef<HTMLDivElement>(null);
  const accRef = useRef<HTMLDivElement>(null);
  const [counts, setCounts] = useState({ cart: 0, wish: 0 });

  useEffect(() => {
    setCounts({ cart: cartCount, wish: wishlist.length });
  }, [cartCount, wishlist.length]);

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (catRef.current && !catRef.current.contains(e.target as Node))
        setCatOpen(false);
      if (accRef.current && !accRef.current.contains(e.target as Node))
        setAccOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    router.push(q.trim() ? `/shop?search=${encodeURIComponent(q.trim())}` : "/shop");
  };

  const linkCls = (active: boolean) =>
    `rounded-full px-4 py-1.5 text-sm font-semibold transition ${
      active ? "bg-white/10 text-white" : "text-slate-300 hover:bg-white/5 hover:text-white"
    }`;

  return (
    <header className="sticky top-0 z-50">
      <Ticker />
      <div className="bg-navy-900">
        {/* main bar */}
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3.5">
          <button
            className="rounded-lg p-2 text-slate-300 hover:bg-white/10 lg:hidden"
            onClick={() => setMobileOpen((v) => !v)}
            aria-label="Menu"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <Logo />

          {/* search */}
          <form
            onSubmit={submit}
            className="mx-auto hidden min-w-0 flex-1 max-w-xl md:flex"
          >
            <div className="flex w-full overflow-hidden rounded-full bg-white ring-1 ring-white/20 focus-within:ring-2 focus-within:ring-orange-400">
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search products..."
                className="min-w-0 flex-1 bg-transparent px-5 py-2.5 text-sm text-slate-800 outline-none placeholder:text-slate-400"
              />
              <button
                type="submit"
                className="flex items-center gap-1.5 bg-orange-500 px-6 text-sm font-bold text-white transition hover:bg-orange-600"
              >
                <Search size={15} strokeWidth={2.5} />
                Search
              </button>
            </div>
          </form>

          {/* actions */}
          <div className="ml-auto flex items-center gap-2 md:ml-0">
            <Link
              href="/wishlist"
              className="relative flex items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-semibold text-slate-200 transition hover:bg-white/10"
            >
              <Heart size={16} />
              <span className="hidden sm:inline">Wishlist</span>
              {counts.wish > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
                  {counts.wish}
                </span>
              )}
            </Link>
            <Link
              href="/cart"
              className="relative flex items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-semibold text-slate-200 transition hover:bg-white/10"
            >
              <ShoppingCart size={16} />
              <span className="hidden sm:inline">Cart</span>
              {counts.cart > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-orange-500 px-1 text-[10px] font-bold text-white">
                  {counts.cart}
                </span>
              )}
            </Link>
            <div className="relative" ref={accRef}>
              <button
                onClick={() => setAccOpen((v) => !v)}
                className="flex items-center gap-1.5 rounded-full px-3 py-2 text-[13px] font-semibold text-slate-200 transition hover:bg-white/10"
              >
                <User size={16} />
                <span className="hidden sm:inline">Account</span>
                <ChevronDown size={12} className={`transition ${accOpen ? "rotate-180" : ""}`} />
              </button>
              {accOpen && (
                <div className="absolute right-0 top-full mt-2 w-44 overflow-hidden rounded-xl bg-white py-1.5 shadow-2xl ring-1 ring-slate-900/10">
                  <Link
                    href="/account?mode=login"
                    className="block px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
                  >
                    Login
                  </Link>
                  <Link
                    href="/account?mode=register"
                    className="block px-4 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
                  >
                    Create Account
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* mobile search */}
        <form onSubmit={submit} className="px-4 pb-3 md:hidden">
          <div className="flex overflow-hidden rounded-full bg-white">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search products..."
              className="min-w-0 flex-1 bg-transparent px-4 py-2 text-sm outline-none"
            />
            <button className="bg-orange-500 px-4 text-white" aria-label="Search">
              <Search size={15} />
            </button>
          </div>
        </form>

        {/* nav row */}
        <nav className="hidden border-t border-white/5 lg:block">
          <div className="mx-auto flex max-w-7xl items-center justify-center gap-1 px-4 py-2">
            <Link href="/" className={linkCls(pathname === "/")}>
              Home
            </Link>
            <Link href="/shop" className={linkCls(pathname === "/shop")}>
              Shop
            </Link>
            <div className="relative" ref={catRef}>
              <button
                onClick={() => setCatOpen((v) => !v)}
                onMouseEnter={() => setCatOpen(true)}
                className="flex items-center gap-1 rounded-full px-4 py-1.5 text-sm font-semibold text-slate-300 transition hover:bg-white/5 hover:text-white"
              >
                Categories
                <ChevronDown size={13} className={`transition ${catOpen ? "rotate-180" : ""}`} />
              </button>
              {catOpen && (
                <div
                  onMouseLeave={() => setCatOpen(false)}
                  className="absolute left-1/2 top-full z-50 mt-2 w-[560px] -translate-x-1/2 rounded-2xl bg-white p-5 shadow-2xl ring-1 ring-slate-900/10"
                >
                  <div className="grid grid-cols-4 gap-4">
                    {categories.map((c) => (
                      <div key={c.slug}>
                        <Link
                          href={`/shop?category=${c.slug}`}
                          onClick={() => setCatOpen(false)}
                          className="text-sm font-bold text-slate-900 hover:text-orange-600"
                        >
                          {c.name}
                        </Link>
                        <ul className="mt-2 space-y-1.5">
                          {c.subs.map((s) => (
                            <li key={s.slug}>
                              <Link
                                href={`/shop?category=${c.slug}&sub=${s.slug}`}
                                onClick={() => setCatOpen(false)}
                                className="flex items-start gap-1 text-[12.5px] text-slate-500 hover:text-orange-600"
                              >
                                <span className="mt-[3px] h-1 w-1 shrink-0 rounded-full bg-slate-300" />
                                {s.name}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <Link
              href="/flash-sale"
              className="relative mx-1 flex items-center gap-1 rounded-full bg-red-600 px-4 py-1.5 text-sm font-bold text-white shadow-lg shadow-red-600/30 transition hover:bg-red-500"
            >
              <Flame size={13} className="fill-amber-300 text-amber-300" />
              Flash Sale
              <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full bg-amber-400 px-1.5 text-[8.5px] font-black tracking-wide text-navy-950">
                HOT
              </span>
            </Link>
            <Link href="/track-order" className={linkCls(pathname === "/track-order")}>
              Track Order
            </Link>
          </div>
        </nav>
      </div>

      {/* mobile drawer */}
      {mobileOpen && (
        <div className="absolute inset-x-0 top-full max-h-[70vh] overflow-y-auto border-t border-white/10 bg-navy-900 px-4 py-4 shadow-2xl lg:hidden">
          <div className="flex flex-col gap-1">
            {[
              { href: "/", label: "Home" },
              { href: "/shop", label: "Shop" },
              { href: "/flash-sale", label: "Flash Sale" },
              { href: "/track-order", label: "Track Order", icon: PackageSearch },
            ].map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="rounded-lg px-3 py-2.5 text-sm font-semibold text-slate-200 hover:bg-white/10"
              >
                {l.label}
              </Link>
            ))}
            <p className="mt-2 px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Categories
            </p>
            {categories.map((c) => (
              <div key={c.slug} className="px-3">
                <Link
                  href={`/shop?category=${c.slug}`}
                  className="py-1.5 text-sm font-semibold text-slate-200"
                >
                  {c.name}
                </Link>
                <div className="flex flex-wrap gap-x-3 pb-1">
                  {c.subs.map((s) => (
                    <Link
                      key={s.slug}
                      href={`/shop?category=${c.slug}&sub=${s.slug}`}
                      className="py-0.5 text-xs text-slate-400 hover:text-orange-400"
                    >
                      {s.name}
                    </Link>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
