"use client";

import { useState } from "react";
import Link from "next/link";
import type { ProductCard } from "@/lib/data";
import { MiniProductCard } from "./ProductCards";

export default function TrendingTabs({
  categories,
  products,
}: {
  categories: { name: string; slug: string }[];
  products: ProductCard[];
}) {
  const [active, setActive] = useState(categories[0]?.slug ?? "");
  const items = products.filter((p) => p.categorySlug === active).slice(0, 3);

  return (
    <div className="flex h-full flex-col rounded-3xl bg-white p-5 shadow-2xl shadow-black/30">
      <div className="flex items-center justify-between">
        <span className="rounded-full bg-navy-900 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white">
          Trending by Category
        </span>
        <Link
          href="/shop"
          className="text-[12px] font-bold text-amber-600 hover:text-amber-500"
        >
          View Shop →
        </Link>
      </div>
      <h3 className="mt-2.5 text-lg font-extrabold tracking-tight text-slate-900">
        Swipe premium picks
      </h3>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {categories.map((c) => (
          <button
            key={c.slug}
            onClick={() => setActive(c.slug)}
            className={`rounded-full px-3.5 py-1.5 text-[12px] font-bold transition ${
              active === c.slug
                ? "bg-navy-900 text-white shadow-md"
                : "bg-slate-100 text-slate-500 hover:bg-slate-200"
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="mt-4 grid flex-1 grid-cols-3 gap-3">
        {items.map((p) => (
          <MiniProductCard key={p.id} product={p} cta="View Product" />
        ))}
        {items.length === 0 && (
          <p className="col-span-3 self-center text-center text-sm text-slate-400">
            No products found in this category yet.
          </p>
        )}
      </div>
    </div>
  );
}
