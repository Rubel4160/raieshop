"use client";

import { useEffect, useState } from "react";

function pad(n: number) {
  return n.toString().padStart(2, "0");
}

export default function Countdown() {
  const [target, setTarget] = useState<number | null>(null);
  const [left, setLeft] = useState({ d: 0, h: 0, m: 0, s: 0, done: false });

  useEffect(() => {
    const t = Date.now() + (2 * 24 * 3600 + 14 * 3600 + 32 * 60) * 1000;
    setTarget(t);
  }, []);

  useEffect(() => {
    if (!target) return;
    const tick = () => {
      const diff = target - Date.now();
      if (diff <= 0) {
        setLeft({ d: 0, h: 0, m: 0, s: 0, done: true });
        return;
      }
      setLeft({
        d: Math.floor(diff / 86400000),
        h: Math.floor(diff / 3600000) % 24,
        m: Math.floor(diff / 60000) % 60,
        s: Math.floor(diff / 1000) % 60,
        done: false,
      });
    };
    tick();
    const iv = setInterval(tick, 1000);
    return () => clearInterval(iv);
  }, [target]);

  const cells = [
    { v: pad(left.d), label: "DAYS" },
    { v: pad(left.h), label: "HOURS" },
    { v: pad(left.m), label: "MINUTES" },
    { v: pad(left.s), label: "SECONDS" },
  ];

  return (
    <div className="mt-8">
      <div className="flex flex-wrap items-center justify-center gap-3">
        {cells.map((c) => (
          <div
            key={c.label}
            className="flex h-24 w-20 flex-col items-center justify-center rounded-2xl bg-white/15 ring-1 ring-white/25 backdrop-blur-sm sm:h-28 sm:w-24"
          >
            <span className="text-3xl font-black text-white sm:text-4xl">{c.v}</span>
            <span className="mt-1 text-[10px] font-bold tracking-widest text-white/70">
              {c.label}
            </span>
          </div>
        ))}
      </div>
      <p className="mt-4 text-center text-sm font-semibold text-amber-300">
        {left.done
          ? "Flash Sale has ended. Stay tuned for the next round!"
          : "Hurry up! Deals refresh when the timer hits zero."}
      </p>
    </div>
  );
}
