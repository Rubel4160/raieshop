import "dotenv/config";
import { db } from "./index";
import {
  categories,
  subcategories,
  products,
  reviews,
} from "./schema";

const IMG = (n: string) => `/images/products/${n}.jpg`;

async function seed() {
  console.log("Seeding RAIESHOP database...");

  await db.delete(products);
  await db.delete(subcategories);
  await db.delete(categories);
  await db.delete(reviews);

  const catRows = await db
    .insert(categories)
    .values([
      {
        name: "Jewellery",
        slug: "jewellery",
        description: "Jewellery products for RAIESHOP.",
        icon: "Gem",
        tint: "from-violet-50 to-purple-50",
        sortOrder: 1,
      },
      {
        name: "Kitchen",
        slug: "kitchen",
        description: "Kitchen products for RAIESHOP.",
        icon: "ChefHat",
        tint: "from-emerald-50 to-teal-50",
        sortOrder: 2,
      },
      {
        name: "Electronics",
        slug: "electronics",
        description: "Electronics products for RAIESHOP.",
        icon: "Headphones",
        tint: "from-sky-50 to-blue-50",
        sortOrder: 3,
      },
      {
        name: "Fashion",
        slug: "fashion",
        description: "Fashion products for RAIESHOP.",
        icon: "Shirt",
        tint: "from-amber-50 to-orange-50",
        sortOrder: 4,
      },
    ])
    .returning();

  const catId = (slug: string) => catRows.find((c) => c.slug === slug)!.id;

  const subDefs: Record<string, string[]> = {
    jewellery: ["Necklaces", "Earrings", "Rings", "Bracelets", "Gift Sets"],
    kitchen: [
      "Storage & Organizers",
      "Cookware Tools",
      "Cleaning Accessories",
      "Utility Tools",
      "Dining Accessories",
    ],
    electronics: [
      "Smart Gadgets",
      "Mobile Accessories",
      "Audio",
      "Small Devices",
    ],
    fashion: ["Women's Wear", "Kids Wear", "Bags", "Accessories", "Gift Sets"],
  };

  const slugify = (s: string) =>
    s
      .toLowerCase()
      .replace(/'/g, "")
      .replace(/&/g, "and")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");

  const subValues = Object.entries(subDefs).flatMap(([catSlug, subs]) =>
    subs.map((name) => ({
      categoryId: catId(catSlug),
      name,
      slug: `${catSlug}-${slugify(name)}`,
    }))
  );

  const subRows = await db.insert(subcategories).values(subValues).returning();
  const subId = (slug: string) => subRows.find((s) => s.slug === slug)!.id;

  type P = {
    name: string;
    slug: string;
    description: string;
    image: string;
    price: number;
    salePrice?: number;
    stock: number;
    cat: string;
    sub: string;
    hasOptions?: boolean;
    sizes?: string;
    colors?: string;
    featured?: boolean;
    flash?: boolean;
    best?: boolean;
  };

  const defs: P[] = [
    {
      name: "Wrist watch",
      slug: "wrist-watch",
      description:
        "Classic analog wrist watch with a premium stainless steel body and comfortable leather strap for everyday style.",
      image: IMG("accessories"),
      price: 5000,
      stock: 20,
      cat: "jewellery",
      sub: "jewellery-bracelets",
      hasOptions: true,
      sizes: "38mm,42mm",
      colors: "Black,Brown,Silver",
      featured: true,
    },
    {
      name: "Diamond Ring",
      slug: "diamond-ring",
      description:
        "Both sides are featuring in the knockout rounds of a World Cup for the first time, so further history awaits.",
      image: IMG("jewellery"),
      price: 10000,
      stock: 10,
      cat: "jewellery",
      sub: "jewellery-rings",
      hasOptions: true,
      sizes: "16,17,18,19",
      colors: "Gold,Silver",
      featured: true,
    },
    {
      name: "Nupur",
      slug: "nupur",
      description:
        "Both sides are featuring in the knockout rounds of a World Cup for the first time, so further history awaits.",
      image: IMG("jewellery"),
      price: 5000,
      salePrice: 4500,
      stock: 47,
      cat: "jewellery",
      sub: "jewellery-necklaces",
      hasOptions: true,
      sizes: "Free Size",
      colors: "Gold,Silver",
      featured: true,
      flash: true,
      best: true,
    },
    {
      name: "Earring",
      slug: "earring",
      description: "1914 translation by H. Rackham",
      image: IMG("jewellery"),
      price: 10500,
      salePrice: 10000,
      stock: 32,
      cat: "jewellery",
      sub: "jewellery-earrings",
      featured: true,
      flash: true,
      best: true,
    },
    {
      name: "Cookpan",
      slug: "cookpan",
      description:
        'Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC.',
      image: IMG("kitchen"),
      price: 850,
      salePrice: 750,
      stock: 0,
      cat: "kitchen",
      sub: "kitchen-cookware-tools",
      hasOptions: true,
      sizes: "20cm,24cm,28cm",
      colors: "Black,Maroon",
      featured: true,
      flash: true,
      best: true,
    },
    {
      name: "Pan",
      slug: "pan",
      description: "The standard Lorem Ipsum passage, used since 1916.",
      image: IMG("pan"),
      price: 2000,
      salePrice: 1550,
      stock: 19,
      cat: "kitchen",
      sub: "kitchen-cookware-tools",
      flash: true,
    },
    {
      name: "Kitchen Rack",
      slug: "kitchen-rack",
      description: "1914 translation by H. Rackham.",
      image: IMG("kitchen"),
      price: 5000,
      stock: 4,
      cat: "kitchen",
      sub: "kitchen-utility-tools",
      featured: true,
    },
    {
      name: "Earing",
      slug: "earing",
      description:
        'Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC.',
      image: IMG("electronics"),
      price: 30000,
      salePrice: 25000,
      stock: 0,
      cat: "electronics",
      sub: "electronics-mobile-accessories",
      hasOptions: true,
      sizes: "Standard",
      colors: "White,Black",
      featured: true,
      flash: true,
      best: true,
    },
    {
      name: "Headphone",
      slug: "headphone",
      description:
        'Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC.',
      image: IMG("headphone"),
      price: 450,
      salePrice: 400,
      stock: 0,
      cat: "electronics",
      sub: "electronics-audio",
      featured: true,
      flash: true,
      best: true,
    },
    {
      name: "Android TV",
      slug: "android-tv",
      description:
        "Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.",
      image: IMG("tv"),
      price: 26000,
      salePrice: 22999,
      stock: 49,
      cat: "electronics",
      sub: "electronics-small-devices",
      flash: true,
    },
    {
      name: "Sharee",
      slug: "sharee",
      description: "Premium soft silk sharee with elegant border work for festive and daily elegance.",
      image: IMG("dress"),
      price: 14000,
      salePrice: 10000,
      stock: 0,
      cat: "fashion",
      sub: "fashion-gift-sets",
      hasOptions: true,
      sizes: "Free Size",
      colors: "Pink,Maroon,Teal",
      featured: true,
      flash: true,
    },
    {
      name: "Dress",
      slug: "dress",
      description:
        'Section 1.10.33 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC.',
      image: IMG("fashion"),
      price: 8550,
      stock: 24,
      cat: "fashion",
      sub: "fashion-womens-wear",
      hasOptions: true,
      sizes: "S,M,L,XL",
      colors: "Pink,Blue,Black",
      featured: true,
      best: true,
    },
    {
      name: "Toys",
      slug: "toys",
      description: "1914 translation by H. Rackham",
      image: IMG("accessories"),
      price: 4500,
      salePrice: 2550,
      stock: 0,
      cat: "fashion",
      sub: "fashion-kids-wear",
      featured: true,
      flash: true,
    },
    {
      name: "Bags",
      slug: "bags",
      description:
        'Section 1.10.33 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC.',
      image: IMG("bags"),
      price: 5000,
      salePrice: 2550,
      stock: 17,
      cat: "fashion",
      sub: "fashion-bags",
      featured: true,
      flash: true,
    },
    {
      name: "Sneakers",
      slug: "sneakers",
      description:
        "Lightweight cushioned sneakers built for daily comfort, breathable mesh and durable outsole grip.",
      image: IMG("fashion"),
      price: 2250,
      stock: 15,
      cat: "fashion",
      sub: "fashion-womens-wear",
      hasOptions: true,
      sizes: "39,40,41,42,43",
      colors: "White,Black,Pink",
    },
    {
      name: "Accessories Combo",
      slug: "accessories-combo",
      description:
        "A curated combo of daily fashion accessories: belt, wallet and sunglasses for a complete look.",
      image: IMG("accessories"),
      price: 3200,
      stock: 12,
      cat: "fashion",
      sub: "fashion-accessories",
    },
  ];

  await db.insert(products).values(
    defs.map((d) => ({
      name: d.name,
      slug: d.slug,
      description: d.description,
      image: d.image,
      price: d.price,
      salePrice: d.salePrice ?? null,
      stock: d.stock,
      categoryId: catId(d.cat),
      subcategoryId: subId(d.sub),
      hasOptions: d.hasOptions ?? false,
      sizes: d.sizes ?? "",
      colors: d.colors ?? "",
      isFeatured: d.featured ?? false,
      isFlashSale: d.flash ?? false,
      isBestSeller: d.best ?? false,
    }))
  );

  await db.insert(reviews).values([
    {
      name: "Nusrat Jahan",
      comment:
        "RAIESHOP made my online shopping experience simple and smooth. Product display and order process felt very easy.",
      rating: 5,
    },
    {
      name: "Amit Hasan",
      comment:
        "Fast delivery and cash on delivery made everything convenient. Recommended for premium picks.",
      rating: 5,
    },
    {
      name: "Sharmin Akter",
      comment:
        "Ordered a sharee during the flash sale. Great quality for the price, and tracking my order was super easy.",
      rating: 4,
    },
  ]);

  console.log("Seed complete:", defs.length, "products inserted.");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
