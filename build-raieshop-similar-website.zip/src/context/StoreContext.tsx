"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

export type CartItem = {
  id: number;
  slug: string;
  name: string;
  image: string;
  price: number;
  qty: number;
  variant: string;
};

export type WishlistItem = {
  id: number;
  slug: string;
  name: string;
  image: string;
  price: number;
  salePrice: number | null;
  category: string;
  stock: number;
};

type StoreContextValue = {
  cart: CartItem[];
  wishlist: WishlistItem[];
  cartCount: number;
  cartTotal: number;
  addToCart: (item: Omit<CartItem, "qty">, qty?: number) => void;
  updateQty: (id: number, variant: string, qty: number) => void;
  removeFromCart: (id: number, variant: string) => void;
  clearCart: () => void;
  toggleWishlist: (item: WishlistItem) => void;
  isWishlisted: (id: number) => boolean;
  toast: string | null;
  notify: (msg: string) => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

const CART_KEY = "raieshop_cart";
const WISH_KEY = "raieshop_wishlist";

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    try {
      const c = localStorage.getItem(CART_KEY);
      const w = localStorage.getItem(WISH_KEY);
      if (c) setCart(JSON.parse(c));
      if (w) setWishlist(JSON.parse(w));
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart, hydrated]);

  useEffect(() => {
    if (hydrated) localStorage.setItem(WISH_KEY, JSON.stringify(wishlist));
  }, [wishlist, hydrated]);

  const notify = useCallback((msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2400);
  }, []);

  const addToCart = useCallback(
    (item: Omit<CartItem, "qty">, qty = 1) => {
      setCart((prev) => {
        const key = (i: CartItem) => `${i.id}::${i.variant}`;
        const target = key({ ...item, qty });
        const existing = prev.find((i) => key(i) === target);
        if (existing) {
          return prev.map((i) =>
            key(i) === target ? { ...i, qty: i.qty + qty } : i
          );
        }
        return [...prev, { ...item, qty }];
      });
      notify(`${item.name} added to cart`);
    },
    [notify]
  );

  const updateQty = useCallback(
    (id: number, variant: string, qty: number) => {
      if (qty <= 0) {
        setCart((prev) =>
          prev.filter((i) => !(i.id === id && i.variant === variant))
        );
        return;
      }
      setCart((prev) =>
        prev.map((i) =>
          i.id === id && i.variant === variant ? { ...i, qty } : i
        )
      );
    },
    []
  );

  const removeFromCart = useCallback((id: number, variant: string) => {
    setCart((prev) =>
      prev.filter((i) => !(i.id === id && i.variant === variant))
    );
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const toggleWishlist = useCallback(
    (item: WishlistItem) => {
      setWishlist((prev) => {
        const exists = prev.some((i) => i.id === item.id);
        notify(
          exists
            ? `${item.name} removed from wishlist`
            : `${item.name} saved to wishlist`
        );
        return exists ? prev.filter((i) => i.id !== item.id) : [...prev, item];
      });
    },
    [notify]
  );

  const isWishlisted = useCallback(
    (id: number) => wishlist.some((i) => i.id === id),
    [wishlist]
  );

  const value = useMemo<StoreContextValue>(
    () => ({
      cart,
      wishlist,
      cartCount: cart.reduce((s, i) => s + i.qty, 0),
      cartTotal: cart.reduce((s, i) => s + i.price * i.qty, 0),
      addToCart,
      updateQty,
      removeFromCart,
      clearCart,
      toggleWishlist,
      isWishlisted,
      toast,
      notify,
    }),
    [
      cart,
      wishlist,
      addToCart,
      updateQty,
      removeFromCart,
      clearCart,
      toggleWishlist,
      isWishlisted,
      toast,
      notify,
    ]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

export function Toast() {
  const { toast } = useStore();
  if (!toast) return null;
  return (
    <div className="fixed bottom-20 left-1/2 z-[90] -translate-x-1/2 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-semibold text-white shadow-2xl shadow-navy-900/30 ring-1 ring-white/10">
      {toast}
    </div>
  );
}
