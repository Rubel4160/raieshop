import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ChevronRight,
  Package,
  RotateCcw,
  ShieldCheck,
  Truck,
} from "lucide-react";
import { getProductBySlug, getRelatedProducts } from "@/lib/data";
import { discountPercent, taka } from "@/lib/site";
import PDPOptions from "@/components/store/PDPOptions";
import { WishlistHeart } from "@/components/store/Buttons";
import { ShopProductCard } from "@/components/store/ProductCards";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  return { title: product ? product.name : "Product" };
}

export default async function ProductPage({ params }: { params: Params }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product.categorySlug, product.id);
  const off = discountPercent(product.price, product.salePrice);

  const perks = [
    { icon: Truck, label: "Fast Delivery", desc: "All over Bangladesh" },
    { icon: ShieldCheck, label: "Secure Payment", desc: "COD, bKash, Nagad" },
    { icon: Package, label: "Easy Tracking", desc: "Track anytime" },
    { icon: RotateCcw, label: "Easy Return", desc: "7-day return policy" },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      {/* breadcrumbs */}
      <nav className="flex flex-wrap items-center gap-1.5 text-[12.5px] font-semibold text-slate-400">
        <Link href="/" className="hover:text-orange-600">Home</Link>
        <ChevronRight size={13} />
        <Link href="/shop" className="hover:text-orange-600">Shop</Link>
        <ChevronRight size={13} />
        <Link
          href={`/shop?category=${product.categorySlug}`}
          className="hover:text-orange-600"
        >
          {product.category}
        </Link>
        <ChevronRight size={13} />
        <span className="text-slate-700">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        {/* image */}
        <div className="relative overflow-hidden rounded-3xl bg-white ring-1 ring-slate-100">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.image}
            alt={product.name}
            className="aspect-square w-full object-cover sm:aspect-[4/3] lg:aspect-square"
          />
          <div className="absolute left-4 top-4 flex gap-2">
            {product.isFeatured && (
              <span className="rounded-full bg-navy-900 px-3 py-1 text-[10.5px] font-bold text-white">
                Featured
              </span>
            )}
            {off > 0 && (
              <span className="rounded-full bg-red-500 px-3 py-1 text-[10.5px] font-bold text-white">
                {off}% OFF
              </span>
            )}
          </div>
        </div>

        {/* info */}
        <div>
          <div className="flex items-center gap-2">
            <span className="rounded-md bg-blue-50 px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wide text-blue-600">
              {product.category}
            </span>
            {product.subcategory && (
              <span className="rounded-md bg-slate-100 px-2.5 py-1 text-[10.5px] font-semibold text-slate-500">
                {product.subcategory}
              </span>
            )}
          </div>

          <h1 className="mt-3 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            {product.name}
          </h1>

          <div className="mt-3 flex flex-wrap items-baseline gap-2.5">
            {product.salePrice && (
              <span className="text-lg font-semibold text-slate-400 line-through">
                {taka(product.price)}
              </span>
            )}
            <span className={`text-3xl font-black ${product.salePrice ? "text-red-600" : "text-blue-600"}`}>
              {taka(product.salePrice ?? product.price)}
            </span>
            {product.salePrice && (
              <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-600 ring-1 ring-emerald-100">
                You save {taka(product.price - product.salePrice)}
              </span>
            )}
          </div>

          <p className="mt-2 text-[12.5px] font-bold">
            {product.stock > 0 ? (
              <span className="text-emerald-600">In Stock — {product.stock} pcs available</span>
            ) : (
              <span className="text-red-500">Out of Stock</span>
            )}
          </p>

          <p className="mt-4 max-w-xl text-[14px] leading-relaxed text-slate-600">
            {product.description}
          </p>

          <div className="flex items-start gap-3">
            <div className="flex-1">
              <PDPOptions product={product} />
            </div>
            <WishlistHeart product={product} className="mt-6 h-12 w-12" />
          </div>

          {/* perks */}
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {perks.map((p) => (
              <div
                key={p.label}
                className="rounded-xl bg-white p-3.5 text-center ring-1 ring-slate-100"
              >
                <p.icon size={18} className="mx-auto text-orange-500" />
                <p className="mt-1.5 text-[11.5px] font-bold text-slate-800">{p.label}</p>
                <p className="text-[10.5px] text-slate-400">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* related */}
      {related.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-black tracking-tight text-slate-900">
            Related Products
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            More picks from the {product.category} collection.
          </p>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((p) => (
              <ShopProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
