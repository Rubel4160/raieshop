import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  ChefHat,
  Flame,
  Gem,
  Headphones,
  Package,
  ShieldCheck,
  Shirt,
  Sparkles,
  Star,
  Timer,
  Truck,
} from "lucide-react";
import {
  getBestSellers,
  getCategories,
  getFlashSaleProducts,
  getFeaturedByCategory,
  getReviews,
} from "@/lib/data";
import TrendingTabs from "@/components/store/TrendingTabs";
import NewsletterForm from "@/components/store/NewsletterForm";
import {
  BestSellerCard,
  MiniProductCard,
  ShopProductCard,
} from "@/components/store/ProductCards";

export const dynamic = "force-dynamic";

const iconMap: Record<string, typeof Gem> = {
  Gem,
  ChefHat,
  Headphones,
  Shirt,
};

const lifestyleMeta: Record<
  string,
  { title: string; desc: string; chip: string }
> = {
  fashion: {
    title: "Fashion Picks",
    desc: "Trending fashion products for daily style and modern looks.",
    chip: "Fashion",
  },
  jewellery: {
    title: "Jewellery Collection",
    desc: "Elegant jewellery pieces designed for premium presentation.",
    chip: "Jewellery",
  },
  electronics: {
    title: "Electronics Deals",
    desc: "Smart gadgets and electronics curated for modern customers.",
    chip: "Electronics",
  },
  kitchen: {
    title: "Kitchen Essentials",
    desc: "Useful kitchen and home picks for everyday convenience.",
    chip: "Kitchen",
  },
};

export default async function HomePage() {
  const [categories, featured, flash, best, reviews] = await Promise.all([
    getCategories(),
    getFeaturedByCategory(),
    getFlashSaleProducts(),
    getBestSellers(),
    getReviews(),
  ]);

  const navCats = categories.map((c) => ({ name: c.name, slug: c.slug }));

  return (
    <div>
      {/* ======================= HERO ======================= */}
      <section className="mx-auto max-w-7xl px-4 pt-5">
        <div className="grid gap-5 lg:grid-cols-2">
          {/* left: hero */}
          <div className="reveal relative overflow-hidden rounded-3xl bg-navy-900 p-8 sm:p-10">
            <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-violet-600/25 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-28 -right-20 h-80 w-80 rounded-full bg-orange-500/15 blur-3xl" />
            <div className="relative">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-400/15 px-3.5 py-1.5 text-[10.5px] font-bold uppercase tracking-widest text-amber-300 ring-1 ring-amber-400/30">
                <Sparkles size={12} />
                Premium Lifestyle Collection
              </span>
              <h1 className="mt-5 text-4xl font-black leading-[1.12] tracking-tight text-white sm:text-5xl">
                Shop Smart.
                <br />
                Style Better.
                <br />
                <span className="bg-gradient-to-r from-amber-300 to-orange-500 bg-clip-text text-transparent">
                  Live Easier.
                </span>
              </h1>
              <p className="mt-4 max-w-md text-[15px] leading-relaxed text-slate-400">
                Discover fashion, jewellery, electronics, kitchen essentials, and
                handpicked trending items in one place.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <Link
                  href="/shop"
                  className="rounded-full bg-orange-500 px-7 py-3 text-sm font-bold text-white shadow-xl shadow-orange-600/30 transition hover:bg-orange-600"
                >
                  Shop Now
                </Link>
                <Link
                  href="/track-order"
                  className="rounded-full border border-white/25 px-7 py-3 text-sm font-bold text-slate-200 transition hover:bg-white/10"
                >
                  Track Order
                </Link>
              </div>
              <div className="mt-8 flex flex-wrap gap-2.5">
                {[
                  { icon: Truck, label: "Fast Delivery" },
                  { icon: ShieldCheck, label: "Secure Checkout" },
                  { icon: Package, label: "Easy Tracking" },
                ].map((f) => (
                  <span
                    key={f.label}
                    className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-[12px] font-semibold text-slate-300"
                  >
                    <f.icon size={13} className="text-amber-400" />
                    {f.label}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* right: trending */}
          <div className="reveal [animation-delay:120ms]">
            <TrendingTabs categories={navCats} products={featured} />
          </div>
        </div>
      </section>

      {/* ================= FEATURED CATEGORIES ================= */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="text-center">
          <span className="text-[11px] font-black uppercase tracking-[0.2em] text-rose-500">
            Browse Collections
          </span>
          <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            Featured Categories
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            Quickly jump into the collections your customers love most.
          </p>
        </div>
        <div className="mt-9 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((c, i) => {
            const Icon = iconMap[c.icon] ?? Gem;
            return (
              <Link
                key={c.slug}
                href={`/shop?category=${c.slug}`}
                className="group rounded-2xl bg-white p-6 ring-1 ring-slate-100 transition hover:-translate-y-1.5 hover:shadow-xl hover:shadow-slate-200"
                style={{ animationDelay: `${i * 90}ms` }}
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-50 text-slate-700 ring-1 ring-slate-100 transition group-hover:bg-orange-500 group-hover:text-white">
                  <Icon size={22} />
                </span>
                <h3 className="mt-4 text-[17px] font-extrabold text-slate-900">
                  {c.name}
                </h3>
                <p className="mt-1 text-[12.5px] text-slate-500">{c.description}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-[12.5px] font-bold text-amber-600">
                  Shop Now
                  <ArrowRight
                    size={13}
                    className="transition group-hover:translate-x-1"
                  />
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* ===================== FLASH SALE ===================== */}
      <section className="relative overflow-hidden py-16">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,#fecdd3_0%,transparent_55%),radial-gradient(ellipse_at_bottom_right,#fdba74_0%,transparent_55%),radial-gradient(ellipse_at_center,#fef3c7_0%,#fff1f2_70%)]" />
        <div className="relative mx-auto max-w-7xl px-4">
          <div className="text-center">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-red-100 px-4 py-1.5 text-[11px] font-black uppercase tracking-[0.18em] text-red-600">
              <Flame size={12} className="fill-red-500 text-red-500" />
              Limited Time Deals
            </span>
            <h2 className="mt-3 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
              Flash Sale
            </h2>
            <p className="mt-2 text-sm text-slate-500">
              Exciting discount products selected to help customers buy faster.
            </p>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-[11.5px] font-bold">
              <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-amber-700 ring-1 ring-amber-200">
                <Timer size={12} /> Limited time
              </span>
              <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-red-600 ring-1 ring-red-200">
                <Flame size={12} /> Hot deals
              </span>
              <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-emerald-600 ring-1 ring-emerald-200">
                <CheckCircle2 size={12} /> Ready to order
              </span>
            </div>
            <Link
              href="/flash-sale"
              className="mt-6 inline-block rounded-full bg-red-600 px-8 py-2.5 text-sm font-bold text-white shadow-xl shadow-red-600/30 transition hover:bg-red-500"
            >
              View All Deals
            </Link>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {flash.slice(0, 8).map((p) => (
              <ShopProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* ============== SHOP BY LIFESTYLE CATEGORIES ============== */}
      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="text-center">
          <h2 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            Shop by Lifestyle Categories
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            Explore handpicked premium products by category.
          </p>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {categories.map((c) => {
            const meta = lifestyleMeta[c.slug];
            const items = featured.filter((p) => p.categorySlug === c.slug).slice(0, 4);
            if (!meta) return null;
            return (
              <div
                key={c.slug}
                className={`rounded-3xl bg-gradient-to-br p-6 ring-1 ring-slate-100 ${c.tint}`}
              >
                <span className="rounded-full bg-navy-900 px-3 py-1 text-[10.5px] font-bold uppercase tracking-wider text-white">
                  {meta.chip}
                </span>
                <h3 className="mt-3 text-2xl font-black tracking-tight text-slate-900">
                  {meta.title}
                </h3>
                <p className="mt-1.5 max-w-sm text-[13px] text-slate-500">{meta.desc}</p>
                <Link
                  href={`/shop?category=${c.slug}`}
                  className="mt-4 inline-block rounded-full border border-slate-300 bg-white/60 px-5 py-2 text-[12.5px] font-bold text-slate-800 transition hover:bg-navy-900 hover:text-white"
                >
                  View More
                </Link>
                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
                  {items.map((p) => (
                    <MiniProductCard key={p.id} product={p} />
                  ))}
                  {items.length === 0 && (
                    <p className="col-span-2 py-8 text-center text-sm text-slate-400">
                      New picks are coming soon.
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ===================== BEST SELLERS ===================== */}
      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="text-center">
          <span className="text-[11px] font-black uppercase tracking-[0.2em] text-violet-500">
            Customer Favorites
          </span>
          <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            Best Sellers
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            Popular products customers choose again and again.
          </p>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {best.slice(0, 6).map((p) => (
            <BestSellerCard key={p.id} product={p} />
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link
            href="/shop"
            className="inline-flex items-center gap-1.5 rounded-full bg-navy-900 px-7 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800"
          >
            View All Products →
          </Link>
        </div>
      </section>

      {/* ================ NEWSLETTER + REVIEWS ================ */}
      <section className="mx-auto max-w-7xl px-4 py-14">
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl bg-white p-8 ring-1 ring-slate-100">
            <h3 className="text-2xl font-black tracking-tight text-slate-900">
              Join Our Newsletter
            </h3>
            <p className="mt-1.5 text-[13.5px] text-slate-500">
              Get offers, updates, and new product news directly in your inbox.
            </p>
            <div className="mt-5">
              <NewsletterForm />
            </div>
          </div>
          <div className="rounded-2xl bg-white p-8 ring-1 ring-slate-100">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-2xl font-black tracking-tight text-slate-900">
                  Customer Reviews
                </h3>
                <p className="mt-1.5 text-[13.5px] text-slate-500">
                  Real feedback from happy customers.
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-[10px] font-black tracking-widest text-emerald-600 ring-1 ring-emerald-100">
                <span className="h-1.5 w-1.5 animate-soft-pulse rounded-full bg-emerald-500" />
                LIVE
              </span>
            </div>
            <div className="mt-5 space-y-4">
              {reviews.slice(0, 3).map((r) => (
                <div key={r.id} className="border-b border-slate-100 pb-3.5 last:border-0 last:pb-0">
                  <div className="flex items-center justify-between">
                    <p className="text-[13.5px] font-bold text-slate-900">{r.name}</p>
                    <span className="flex gap-0.5">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          size={11}
                          className={
                            i < r.rating
                              ? "fill-amber-400 text-amber-400"
                              : "text-slate-200"
                          }
                        />
                      ))}
                    </span>
                  </div>
                  <p className="mt-1 text-[12.5px] leading-relaxed text-slate-500">
                    &quot;{r.comment}&quot;
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
