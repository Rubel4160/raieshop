import Link from "next/link";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  destroySession,
  getSessionUser,
  hashPassword,
  verifyPassword,
} from "@/lib/auth";
import { LogOut, Mail, User, UserRound } from "lucide-react";

export const metadata = { title: "Account" };

async function loginAction(formData: FormData) {
  "use server";
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];
  if (!user || !verifyPassword(password, user.passwordHash)) {
    redirect("/account?mode=login&error=Invalid+email+or+password");
  }
  await createSession(user.id);
  redirect("/account");
}

async function registerAction(formData: FormData) {
  "use server";
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  if (!name || !email || password.length < 6) {
    redirect("/account?mode=register&error=Please+fill+all+fields+(password+min+6+chars)");
  }
  const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing[0]) {
    redirect("/account?mode=register&error=This+email+is+already+registered");
  }
  const [user] = await db
    .insert(users)
    .values({ name, email, passwordHash: hashPassword(password) })
    .returning();
  await createSession(user.id);
  redirect("/account");
}

async function logoutAction() {
  "use server";
  await destroySession();
  revalidatePath("/account");
  redirect("/account?mode=login");
}

export default async function AccountPage({
  searchParams,
}: {
  searchParams: Promise<{ mode?: string; error?: string }>;
}) {
  const sp = await searchParams;
  const mode = sp.mode === "register" ? "register" : "login";
  const user = await getSessionUser();

  const inputCls =
    "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-navy-900 focus:ring-2 focus:ring-slate-100";

  if (user) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16">
        <div className="rounded-3xl bg-white p-8 text-center ring-1 ring-slate-100 sm:p-10">
          <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-amber-500 text-3xl font-black text-white shadow-lg shadow-orange-500/30">
            {user.name.charAt(0).toUpperCase()}
          </span>
          <h1 className="mt-5 text-2xl font-black tracking-tight text-slate-900">
            Welcome back, {user.name}!
          </h1>
          <p className="mt-1 text-sm text-slate-500">{user.email}</p>
          <p className="mt-1 text-[12px] text-slate-400">
            Member since {new Date(user.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
          </p>
          <div className="mt-7 grid gap-3 sm:grid-cols-2">
            <Link
              href="/track-order"
              className="flex items-center justify-center gap-2 rounded-full bg-navy-900 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
            >
              <Mail size={15} />
              Track My Orders
            </Link>
            <form action={logoutAction}>
              <button className="flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 py-3 text-sm font-bold text-slate-600 transition hover:border-red-200 hover:text-red-500">
                <LogOut size={15} />
                Logout
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16">
      <div className="overflow-hidden rounded-3xl bg-white ring-1 ring-slate-100">
        {/* tabs */}
        <div className="grid grid-cols-2 bg-slate-50 p-1.5">
          <Link
            href="/account?mode=login"
            className={`rounded-2xl py-2.5 text-center text-sm font-bold transition ${
              mode === "login" ? "bg-navy-900 text-white shadow" : "text-slate-500"
            }`}
          >
            Login
          </Link>
          <Link
            href="/account?mode=register"
            className={`rounded-2xl py-2.5 text-center text-sm font-bold transition ${
              mode === "register" ? "bg-navy-900 text-white shadow" : "text-slate-500"
            }`}
          >
            Create Account
          </Link>
        </div>

        <div className="p-8">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-orange-50 text-orange-500">
            <UserRound size={24} />
          </span>
          <h1 className="mt-4 text-center text-2xl font-black tracking-tight text-slate-900">
            {mode === "login" ? "Welcome Back" : "Join RAIESHOP"}
          </h1>
          <p className="mt-1.5 text-center text-[13px] text-slate-500">
            {mode === "login"
              ? "Login to manage your orders and wishlist."
              : "Create an account for faster checkout and tracking."}
          </p>

          {sp.error && (
            <p className="mt-4 rounded-xl bg-red-50 px-4 py-2.5 text-center text-[12.5px] font-semibold text-red-600">
              {sp.error}
            </p>
          )}

          <form
            action={mode === "login" ? loginAction : registerAction}
            className="mt-6 space-y-4"
          >
            {mode === "register" && (
              <div>
                <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                  Full Name
                </label>
                <input name="name" required placeholder="Your name" className={inputCls} />
              </div>
            )}
            <div>
              <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                Email Address
              </label>
              <input
                name="email"
                type="email"
                required
                placeholder="you@example.com"
                className={inputCls}
              />
            </div>
            <div>
              <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                Password
              </label>
              <input
                name="password"
                type="password"
                required
                minLength={6}
                placeholder="Minimum 6 characters"
                className={inputCls}
              />
            </div>
            <button className="w-full rounded-full bg-orange-500 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600">
              {mode === "login" ? "Login" : "Create Account"}
            </button>
          </form>

          <p className="mt-5 flex items-center justify-center gap-1.5 text-center text-[12px] text-slate-400">
            <User size={12} />
            Your data is stored securely on our server.
          </p>
        </div>
      </div>
    </div>
  );
}
