import { Flame, Zap } from "lucide-react";
import { getFlashSaleProducts } from "@/lib/data";
import Countdown from "@/components/store/Countdown";
import { FlashProductCard } from "@/components/store/ProductCards";

export const metadata = { title: "Flash Sale" };

export const dynamic = "force-dynamic";

export default async function FlashSalePage() {
  const products = await getFlashSaleProducts();

  return (
    <div>
      {/* hero */}
      <div className="bg-gradient-to-br from-red-600 via-red-500 to-red-600">
        <div className="border-b border-white/10 bg-red-700/60">
          <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-4 gap-y-1 px-4 py-2.5 text-center text-[12.5px] font-semibold text-white">
            <span className="flex items-center gap-1.5 font-bold">
              <Zap size={13} className="fill-amber-300 text-amber-300" />
              Flash Sale Live Now
            </span>
            <span className="hidden text-white/70 sm:inline">
              Limited-time deals on selected premium products
            </span>
            <span className="hidden text-amber-200 md:inline">
              Hurry before stock runs out
            </span>
          </div>
        </div>

        <div className="mx-auto max-w-7xl px-4 py-16 text-center">
          <span className="rounded-full bg-amber-400 px-4 py-1.5 text-[11px] font-black uppercase tracking-widest text-navy-950 shadow-lg">
            Limited Time Offer
          </span>
          <h1 className="mt-4 text-4xl font-black tracking-tight text-white sm:text-5xl">
            Flash Sale
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-[14.5px] leading-relaxed text-red-100">
            Premium discounted products available for a limited time. Grab them
            before they are gone.
          </p>
          <Countdown />
        </div>
      </div>

      {/* products */}
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-8 flex items-center justify-center gap-2 rounded-full bg-red-50 py-3 text-[13px] font-bold text-red-600 ring-1 ring-red-100">
          <Flame size={15} className="fill-red-500 text-red-500" />
          Best discounted products are listed below. Sale items can end anytime,
          so order now.
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p) => (
            <FlashProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
