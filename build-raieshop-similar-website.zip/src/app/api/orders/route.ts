import { NextResponse } from "next/server";
import { db } from "@/db";
import { orderItems, orders, products } from "@/db/schema";
import { inArray, sql } from "drizzle-orm";
import { SITE } from "@/lib/site";

type ItemIn = { id: number; qty: number; variant?: string };

function genOrderNumber() {
  const now = new Date();
  const yymmdd = `${String(now.getFullYear()).slice(2)}${String(
    now.getMonth() + 1
  ).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const rand = Math.random().toString(36).slice(2, 7).toUpperCase();
  return `RAI-${yymmdd}-${rand}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, phone, address, note, payment, area, items } = body as {
      name?: string;
      phone?: string;
      address?: string;
      note?: string;
      payment?: string;
      area?: string;
      items?: ItemIn[];
    };

    if (!name?.trim() || !phone?.trim() || !address?.trim()) {
      return NextResponse.json(
        { error: "Name, phone and address are required." },
        { status: 400 }
      );
    }
    if (!items || items.length === 0) {
      return NextResponse.json({ error: "Your cart is empty." }, { status: 400 });
    }

    const ids = items.map((i) => i.id);
    const dbProducts = await db
      .select()
      .from(products)
      .where(inArray(products.id, ids));

    let subtotal = 0;
    const validated = items.map((item) => {
      const p = dbProducts.find((d) => d.id === item.id);
      if (!p) throw new Error("A product in your cart no longer exists.");
      const unitPrice = p.salePrice ?? p.price;
      const qty = Math.max(1, Math.min(99, Math.floor(item.qty) || 1));
      subtotal += unitPrice * qty;
      return {
        productName: p.name,
        productSlug: p.slug,
        variant: (item.variant ?? "").slice(0, 120),
        unitPrice,
        quantity: qty,
        stock: p.stock,
      };
    });

    const outOfStock = validated.find((v) => v.stock <= 0);
    if (outOfStock) {
      return NextResponse.json(
        { error: `"${outOfStock.productName}" is currently out of stock.` },
        { status: 400 }
      );
    }

    const deliveryCharge =
      subtotal >= SITE.freeDeliveryOver
        ? 0
        : area === "outside"
          ? SITE.deliveryOutside
          : SITE.deliveryInside;

    const [order] = await db
      .insert(orders)
      .values({
        orderNumber: genOrderNumber(),
        customerName: name.trim(),
        phone: phone.trim(),
        address: address.trim(),
        note: (note ?? "").trim(),
        paymentMethod: ["cod", "bkash", "nagad"].includes(payment ?? "")
          ? payment!
          : "cod",
        deliveryArea: area === "outside" ? "outside" : "inside",
        subtotal,
        deliveryCharge,
        total: subtotal + deliveryCharge,
        status: "processing",
      })
      .returning();

    await db.insert(orderItems).values(
      validated.map((v) => ({
        orderId: order.id,
        productName: v.productName,
        productSlug: v.productSlug,
        variant: v.variant,
        unitPrice: v.unitPrice,
        quantity: v.quantity,
      }))
    );

    // reduce stock
    for (const item of items) {
      await db
        .update(products)
        .set({ stock: sql`greatest(${products.stock} - ${Math.max(1, item.qty)}, 0)` })
        .where(sql`${products.id} = ${item.id}`);
    }

    return NextResponse.json({ orderNumber: order.orderNumber });
  } catch (err) {
    console.error("Order creation failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to place order." },
      { status: 500 }
    );
  }
}
