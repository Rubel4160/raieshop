import { NextResponse } from "next/server";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const { orderNumber, phone } = (await req.json()) as {
      orderNumber?: string;
      phone?: string;
    };

    if (!orderNumber?.trim() || !phone?.trim()) {
      return NextResponse.json(
        { error: "Order number and phone number are required." },
        { status: 400 }
      );
    }

    const rows = await db
      .select()
      .from(orders)
      .where(
        and(
          eq(sql`upper(${orders.orderNumber})`, orderNumber.trim().toUpperCase()),
          eq(orders.phone, phone.trim())
        )
      )
      .limit(1);

    const order = rows[0];
    if (!order) {
      return NextResponse.json(
        { error: "No order found with this order number and phone number." },
        { status: 404 }
      );
    }

    const items = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, order.id));

    return NextResponse.json({ order, items });
  } catch (err) {
    console.error("Track order failed:", err);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}
