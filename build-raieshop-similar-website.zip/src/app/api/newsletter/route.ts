import { NextResponse } from "next/server";
import { db } from "@/db";
import { newsletterSubscribers } from "@/db/schema";

export async function POST(req: Request) {
  try {
    const { email } = (await req.json()) as { email?: string };
    const clean = (email ?? "").trim().toLowerCase();
    if (!clean || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean)) {
      return NextResponse.json({ error: "Invalid email" }, { status: 400 });
    }
    await db
      .insert(newsletterSubscribers)
      .values({ email: clean })
      .onConflictDoNothing();
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Newsletter failed:", err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}
