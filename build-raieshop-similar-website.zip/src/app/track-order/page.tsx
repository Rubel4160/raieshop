"use client";

import { useState } from "react";
import {
  CheckCircle2,
  CircleDashed,
  Loader2,
  PackageSearch,
} from "lucide-react";
import { taka } from "@/lib/site";

type TrackedOrder = {
  order: {
    orderNumber: string;
    customerName: string;
    address: string;
    paymentMethod: string;
    subtotal: number;
    deliveryCharge: number;
    total: number;
    status: string;
    createdAt: string;
  };
  items: {
    id: number;
    productName: string;
    variant: string;
    unitPrice: number;
    quantity: number;
  }[];
};

const STATUS_LABEL: Record<string, string> = {
  pending: "Order Placed",
  processing: "Processing",
  shipped: "Shipped",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export default function TrackOrderPage() {
  const [orderNumber, setOrderNumber] = useState("");
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<TrackedOrder | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch("/api/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderNumber, phone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Not found");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const steps = ["pending", "processing", "shipped", "delivered"];
  const currentIdx = result
    ? Math.max(0, steps.indexOf(result.order.status))
    : -1;

  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <div className="text-center">
        <h1 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
          Track Your Order
        </h1>
        <p className="mt-2.5 text-sm text-slate-500">
          Enter your order number and phone number to check the latest order status.
        </p>
      </div>

      <form
        onSubmit={submit}
        className="mx-auto mt-8 grid gap-4 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-100 sm:grid-cols-[1fr_1fr_auto] sm:items-end"
      >
        <div>
          <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
            Order Number / ID
          </label>
          <input
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            required
            placeholder="Example: RAI-260614-ABCDE"
            className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none transition focus:border-navy-900"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
            Phone Number
          </label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            placeholder="Enter your phone number"
            className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none transition focus:border-navy-900"
          />
        </div>
        <button
          disabled={loading}
          className="flex items-center justify-center gap-2 rounded-xl bg-navy-900 px-8 py-3 text-sm font-bold text-white transition hover:bg-navy-800 disabled:opacity-60"
        >
          {loading ? <Loader2 size={16} className="animate-spin" /> : <PackageSearch size={16} />}
          Track
        </button>
      </form>

      {error && (
        <p className="mx-auto mt-5 max-w-2xl rounded-xl bg-red-50 px-5 py-3.5 text-center text-[13px] font-semibold text-red-600 ring-1 ring-red-100">
          {error}
        </p>
      )}

      {result && (
        <div className="mx-auto mt-8 max-w-3xl rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-100 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-5">
            <div>
              <p className="text-[11px] font-black uppercase tracking-widest text-slate-400">
                Order
              </p>
              <p className="text-lg font-black text-navy-900">
                {result.order.orderNumber}
              </p>
            </div>
            <span
              className={`rounded-full px-4 py-1.5 text-[12px] font-bold capitalize ${
                result.order.status === "cancelled"
                  ? "bg-red-50 text-red-600"
                  : result.order.status === "delivered"
                    ? "bg-emerald-50 text-emerald-600"
                    : "bg-blue-50 text-blue-600"
              }`}
            >
              {STATUS_LABEL[result.order.status] ?? result.order.status}
            </span>
          </div>

          {/* timeline */}
          <div className="mt-6 grid grid-cols-4 gap-1">
            {steps.map((s, i) => {
              const done = i <= currentIdx && result.order.status !== "cancelled";
              return (
                <div key={s} className="flex flex-col items-center text-center">
                  <span
                    className={`flex h-9 w-9 items-center justify-center rounded-full ${
                      done
                        ? "bg-emerald-500 text-white"
                        : "bg-slate-100 text-slate-300"
                    }`}
                  >
                    {done ? <CheckCircle2 size={17} /> : <CircleDashed size={17} />}
                  </span>
                  <span
                    className={`mt-1.5 text-[11px] font-bold ${
                      done ? "text-slate-800" : "text-slate-400"
                    }`}
                  >
                    {STATUS_LABEL[s]}
                  </span>
                  {i < steps.length - 1 && (
                    <span
                      className={`absolute hidden`}
                      aria-hidden
                    />
                  )}
                </div>
              );
            })}
          </div>

          {/* items */}
          <div className="mt-7 rounded-xl ring-1 ring-slate-100">
            {result.items.map((i) => (
              <div
                key={i.id}
                className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-0"
              >
                <div>
                  <p className="text-[13px] font-bold text-slate-800">{i.productName}</p>
                  <p className="text-[11px] text-slate-400">
                    {i.variant ? `${i.variant} • ` : ""}Qty {i.quantity}
                  </p>
                </div>
                <span className="text-[13px] font-bold text-slate-700">
                  {taka(i.unitPrice * i.quantity)}
                </span>
              </div>
            ))}
            <div className="space-y-1 bg-slate-50 px-4 py-3 text-[12.5px]">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span>{taka(result.order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Delivery</span>
                <span>
                  {result.order.deliveryCharge === 0
                    ? "FREE"
                    : taka(result.order.deliveryCharge)}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5 font-black text-slate-900">
                <span>Total</span>
                <span>{taka(result.order.total)}</span>
              </div>
            </div>
          </div>

          <div className="mt-5 grid gap-2 text-[12.5px] text-slate-500 sm:grid-cols-2">
            <p>
              <span className="font-bold text-slate-700">Customer:</span>{" "}
              {result.order.customerName}
            </p>
            <p>
              <span className="font-bold text-slate-700">Payment:</span>{" "}
              <span className="uppercase">{result.order.paymentMethod}</span>
            </p>
            <p className="sm:col-span-2">
              <span className="font-bold text-slate-700">Address:</span>{" "}
              {result.order.address}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
