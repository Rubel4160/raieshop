import { notFound } from "next/navigation";
import { SITE } from "@/lib/site";

type Params = Promise<{ slug: string }>;

const PAGES: Record<string, { title: string; body: string[] }> = {
  "about-us": {
    title: "About Us",
    body: [
      `${SITE.name} is a premium lifestyle ecommerce store built for customers in Bangladesh. We curate fashion, jewellery, electronics and kitchen essentials so you can shop smart, style better and live easier.`,
      `Our mission is simple: quality products, transparent pricing in Bangladeshi Taka, and friendly support through WhatsApp and Messenger.`,
    ],
  },
  faq: {
    title: "Frequently Asked Questions",
    body: [
      "Q: How do I place an order? — Add products to cart, go to checkout, fill in your details and place the order. We call to confirm.",
      "Q: Do you offer Cash on Delivery? — Yes, COD is available all over Bangladesh.",
      "Q: How can I track my order? — Use the Track Order page with your order number and phone number.",
      "Q: Is there free delivery? — Yes, orders over ৳2,000 get free delivery.",
    ],
  },
  "privacy-policy": {
    title: "Privacy Policy",
    body: [
      `At ${SITE.name}, we only collect the information required to process your order: name, phone number and delivery address.`,
      "We never sell or share your personal information with third parties. Payment references for bKash/Nagad are used only to verify your payment.",
    ],
  },
  "return-refund": {
    title: "Return & Refund Policy",
    body: [
      "If you receive a damaged or wrong product, contact us within 7 days of delivery with your order number.",
      "After inspection, we will arrange a replacement or full refund. Refunds for manual payments are processed via the same channel within 3-5 working days.",
    ],
  },
  "shipping-policy": {
    title: "Shipping Policy",
    body: [
      "We deliver all over Bangladesh through trusted courier services.",
      `Inside Dhaka delivery charge: ৳60. Outside Dhaka: ৳120. Orders over ৳2,000 enjoy free delivery.`,
      "Estimated delivery time: 24-48 hours inside Dhaka, 2-4 days outside Dhaka.",
    ],
  },
  "terms-conditions": {
    title: "Terms & Conditions",
    body: [
      `By using ${SITE.name}, you agree to provide accurate delivery information and to receive confirmation calls regarding your orders.`,
      "Product prices and availability may change without notice. Flash sale deals are valid while stock lasts.",
    ],
  },
  contact: {
    title: "Contact Us",
    body: [
      `Phone / WhatsApp: ${SITE.phone}`,
      `Email: ${SITE.email}`,
      `Address: ${SITE.address}`,
      "Support hours: 10 AM - 10 PM, every day. Message us on Facebook Messenger or WhatsApp for the fastest response.",
    ],
  },
};

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: PAGES[slug]?.title ?? "Page" };
}

export default async function PolicyPage({ params }: { params: Params }) {
  const { slug } = await params;
  const page = PAGES[slug];
  if (!page) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <div className="text-center">
        <h1 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
          {page.title}
        </h1>
        <p className="mt-2 text-sm text-slate-500">{SITE.name} — {SITE.tagline}</p>
      </div>
      <div className="mt-8 space-y-5 rounded-2xl bg-white p-8 ring-1 ring-slate-100 sm:p-10">
        {page.body.map((p, i) => (
          <p key={i} className="text-[14px] leading-relaxed text-slate-600">
            {p}
          </p>
        ))}
      </div>
    </div>
  );
}
