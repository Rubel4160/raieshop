"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Minus, Plus, ShieldCheck, ShoppingBag, Trash2, Truck } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { SITE, taka } from "@/lib/site";

export default function CartPage() {
  const { cart, updateQty, removeFromCart, cartTotal } = useStore();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const delivery =
    cartTotal >= SITE.freeDeliveryOver ? 0 : cart.length > 0 ? SITE.deliveryInside : 0;

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <span className="rounded-full bg-amber-100 px-3.5 py-1.5 text-[10.5px] font-black uppercase tracking-[0.18em] text-amber-700">
            Secure Cart
          </span>
          <h1 className="mt-3 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            Shopping Cart
          </h1>
          <p className="mt-1.5 text-sm text-slate-500">
            Review your items before checkout.
          </p>
        </div>
        <Link
          href="/shop"
          className="rounded-full border border-slate-900 px-5 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-navy-900 hover:text-white"
        >
          Continue Shopping
        </Link>
      </div>

      {mounted && cart.length > 0 ? (
        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_340px]">
          {/* items */}
          <div className="space-y-4">
            {cart.map((item) => (
              <div
                key={`${item.id}-${item.variant}`}
                className="flex flex-col gap-4 rounded-2xl bg-white p-4 ring-1 ring-slate-100 sm:flex-row sm:items-center"
              >
                <Link
                  href={`/product/${item.slug}`}
                  className="h-24 w-full shrink-0 overflow-hidden rounded-xl bg-slate-50 sm:w-24"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                </Link>
                <div className="min-w-0 flex-1">
                  <Link
                    href={`/product/${item.slug}`}
                    className="text-[15px] font-bold text-slate-900 hover:text-orange-600"
                  >
                    {item.name}
                  </Link>
                  {item.variant && (
                    <p className="mt-0.5 text-[12px] text-slate-400">{item.variant}</p>
                  )}
                  <p className="mt-1 text-[13.5px] font-bold text-blue-600">
                    {taka(item.price)}
                  </p>
                </div>
                <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
                  <div className="inline-flex items-center rounded-full border border-slate-200">
                    <button
                      onClick={() => updateQty(item.id, item.variant, item.qty - 1)}
                      className="px-3 py-1.5 text-slate-500 hover:text-navy-900"
                      aria-label="Decrease"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="min-w-8 text-center text-sm font-bold">{item.qty}</span>
                    <button
                      onClick={() => updateQty(item.id, item.variant, item.qty + 1)}
                      className="px-3 py-1.5 text-slate-500 hover:text-navy-900"
                      aria-label="Increase"
                    >
                      <Plus size={13} />
                    </button>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[14px] font-extrabold text-slate-900">
                      {taka(item.price * item.qty)}
                    </span>
                    <button
                      onClick={() => removeFromCart(item.id, item.variant)}
                      className="text-slate-300 transition hover:text-red-500"
                      aria-label="Remove"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* summary */}
          <aside className="h-fit rounded-2xl bg-white p-6 ring-1 ring-slate-100 lg:sticky lg:top-40">
            <h3 className="text-lg font-extrabold text-slate-900">Order Summary</h3>
            <div className="mt-4 space-y-2.5 text-sm">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">{taka(cartTotal)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Delivery (Inside Dhaka)</span>
                <span className="font-bold text-slate-900">
                  {delivery === 0 ? "FREE" : taka(delivery)}
                </span>
              </div>
              {cartTotal < SITE.freeDeliveryOver && (
                <p className="rounded-lg bg-amber-50 px-3 py-2 text-[11.5px] font-semibold text-amber-700 ring-1 ring-amber-100">
                  Add {taka(SITE.freeDeliveryOver - cartTotal)} more to get FREE delivery!
                </p>
              )}
              <div className="border-t border-slate-100 pt-2.5">
                <div className="flex justify-between">
                  <span className="font-bold text-slate-900">Total</span>
                  <span className="text-lg font-black text-navy-900">
                    {taka(cartTotal + delivery)}
                  </span>
                </div>
              </div>
            </div>
            <Link
              href="/checkout"
              className="mt-5 block rounded-full bg-navy-900 py-3 text-center text-sm font-bold text-white transition hover:bg-navy-800"
            >
              Proceed to Checkout
            </Link>
            <div className="mt-4 space-y-2 text-[11.5px] text-slate-400">
              <p className="flex items-center gap-1.5">
                <ShieldCheck size={13} className="text-emerald-500" /> Secure checkout flow
              </p>
              <p className="flex items-center gap-1.5">
                <Truck size={13} className="text-orange-500" /> Fast delivery across Bangladesh
              </p>
            </div>
          </aside>
        </div>
      ) : (
        <div className="mt-8 rounded-2xl bg-white px-6 py-16 text-center shadow-sm ring-1 ring-slate-100">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-slate-50 text-slate-300">
            <ShoppingBag size={28} />
          </span>
          <h2 className="mt-5 text-2xl font-extrabold tracking-tight text-slate-800">
            Your cart is empty
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            Add products to your cart before proceeding to checkout.
          </p>
          <Link
            href="/shop"
            className="mt-7 inline-block rounded-full bg-navy-900 px-8 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
          >
            Go to Shop
          </Link>
        </div>
      )}
    </div>
  );
}
