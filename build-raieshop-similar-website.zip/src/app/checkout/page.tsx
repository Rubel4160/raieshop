"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Banknote,
  Lock,
  ShoppingBag,
  Smartphone,
  Truck,
} from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { SITE, taka } from "@/lib/site";

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, cartTotal, clearCart } = useStore();
  const [mounted, setMounted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
    note: "",
    payment: "cod",
    area: "inside",
  });

  useEffect(() => setMounted(true), []);

  const delivery =
    cartTotal >= SITE.freeDeliveryOver
      ? 0
      : form.area === "inside"
        ? SITE.deliveryInside
        : SITE.deliveryOutside;

  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (cart.length === 0) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: cart.map((i) => ({
            id: i.id,
            qty: i.qty,
            variant: i.variant,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to place order");
      clearCart();
      router.push(`/order/${data.orderNumber}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to place order");
      setSubmitting(false);
    }
  };

  const inputCls =
    "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-navy-900 focus:ring-2 focus:ring-slate-100";

  if (mounted && cart.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white text-slate-300 ring-1 ring-slate-100">
          <ShoppingBag size={28} />
        </span>
        <h1 className="mt-5 text-2xl font-extrabold text-slate-800">
          Nothing to checkout yet
        </h1>
        <p className="mt-2 text-sm text-slate-500">
          Add a few products to your cart first.
        </p>
        <Link
          href="/shop"
          className="mt-6 inline-block rounded-full bg-navy-900 px-8 py-3 text-sm font-bold text-white"
        >
          Go to Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-3.5 py-1.5 text-[10.5px] font-black uppercase tracking-[0.18em] text-emerald-700">
          <Lock size={11} />
          Secure Checkout
        </span>
        <h1 className="mt-3 text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
          Checkout
        </h1>
        <p className="mt-1.5 text-sm text-slate-500">
          Fill in your delivery details to place the order.
        </p>
      </div>

      <form onSubmit={submit} className="mt-10 grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* form */}
        <div className="space-y-6">
          <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-100">
            <h3 className="text-[15px] font-extrabold text-slate-900">
              Customer Information
            </h3>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                  Full Name *
                </label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  placeholder="Your name"
                  className={inputCls}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                  Phone Number *
                </label>
                <input
                  required
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className={inputCls}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                  Full Address *
                </label>
                <textarea
                  required
                  rows={3}
                  value={form.address}
                  onChange={(e) => set("address", e.target.value)}
                  placeholder="House, road, area, city"
                  className={inputCls}
                />
              </div>
              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
                  Order Note (optional)
                </label>
                <input
                  value={form.note}
                  onChange={(e) => set("note", e.target.value)}
                  placeholder="Any special instruction"
                  className={inputCls}
                />
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-white p-6 ring-1 ring-slate-100">
            <h3 className="text-[15px] font-extrabold text-slate-900">Delivery Area</h3>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {[
                { v: "inside", t: "Inside Dhaka", d: `${taka(SITE.deliveryInside)} charge` },
                { v: "outside", t: "Outside Dhaka", d: `${taka(SITE.deliveryOutside)} charge` },
              ].map((o) => (
                <button
                  type="button"
                  key={o.v}
                  onClick={() => set("area", o.v)}
                  className={`flex items-center gap-3 rounded-xl border p-4 text-left transition ${
                    form.area === o.v
                      ? "border-navy-900 bg-slate-50 ring-1 ring-navy-900"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <Truck size={18} className="text-orange-500" />
                  <span>
                    <span className="block text-[13.5px] font-bold text-slate-800">{o.t}</span>
                    <span className="block text-[11.5px] text-slate-400">{o.d}</span>
                  </span>
                </button>
              ))}
            </div>

            <h3 className="mt-6 text-[15px] font-extrabold text-slate-900">
              Payment Method
            </h3>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {[
                { v: "cod", t: "Cash on Delivery", d: "Pay at your door", icon: Banknote },
                { v: "bkash", t: "Manual bKash", d: "Send Money + note", icon: Smartphone },
                { v: "nagad", t: "Manual Nagad", d: "Send Money + note", icon: Smartphone },
              ].map((o) => (
                <button
                  type="button"
                  key={o.v}
                  onClick={() => set("payment", o.v)}
                  className={`flex flex-col gap-1.5 rounded-xl border p-4 text-left transition ${
                    form.payment === o.v
                      ? "border-navy-900 bg-slate-50 ring-1 ring-navy-900"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <o.icon size={18} className="text-orange-500" />
                  <span className="text-[13px] font-bold text-slate-800">{o.t}</span>
                  <span className="text-[11px] text-slate-400">{o.d}</span>
                </button>
              ))}
            </div>
            {form.payment !== "cod" && (
              <p className="mt-3 rounded-lg bg-pink-50 px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed text-pink-700 ring-1 ring-pink-100">
                Send Money to <b>{SITE.phone}</b> ({form.payment === "bkash" ? "bKash" : "Nagad"} Personal)
                and use your phone number as reference. We will verify and confirm your order.
              </p>
            )}
          </div>
        </div>

        {/* summary */}
        <aside className="h-fit rounded-2xl bg-white p-6 ring-1 ring-slate-100 lg:sticky lg:top-40">
          <h3 className="text-lg font-extrabold text-slate-900">Your Order</h3>
          <div className="mt-4 max-h-56 space-y-3 overflow-y-auto pr-1">
            {cart.map((i) => (
              <div key={`${i.id}-${i.variant}`} className="flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={i.image}
                  alt={i.name}
                  className="h-12 w-12 rounded-lg object-cover ring-1 ring-slate-100"
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12.5px] font-bold text-slate-800">{i.name}</p>
                  <p className="text-[11px] text-slate-400">
                    {i.variant ? `${i.variant} • ` : ""}Qty {i.qty}
                  </p>
                </div>
                <span className="text-[12.5px] font-bold text-slate-700">
                  {taka(i.price * i.qty)}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-sm">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal</span>
              <span className="font-bold text-slate-900">{taka(cartTotal)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Delivery</span>
              <span className="font-bold text-slate-900">
                {delivery === 0 ? "FREE" : taka(delivery)}
              </span>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2">
              <span className="font-bold text-slate-900">Total</span>
              <span className="text-lg font-black text-navy-900">
                {taka(cartTotal + delivery)}
              </span>
            </div>
          </div>
          {error && (
            <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12px] font-semibold text-red-600">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={submitting || cart.length === 0}
            className="mt-5 w-full rounded-full bg-orange-500 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600 disabled:opacity-60"
          >
            {submitting ? "Placing Order..." : "Place Order"}
          </button>
          <p className="mt-3 text-center text-[11px] text-slate-400">
            By placing the order you agree to our terms &amp; conditions.
          </p>
        </aside>
      </form>
    </div>
  );
}
