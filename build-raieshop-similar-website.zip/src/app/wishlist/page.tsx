"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Heart, ShoppingCart, Trash2 } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { taka } from "@/lib/site";

export default function WishlistPage() {
  const { wishlist, toggleWishlist, addToCart } = useStore();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">
            My Wishlist
          </h1>
          <p className="mt-1.5 text-sm text-slate-500">
            Products you saved for later.
          </p>
        </div>
        <Link
          href="/shop"
          className="rounded-full border border-slate-900 px-5 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-navy-900 hover:text-white"
        >
          Continue Shopping
        </Link>
      </div>

      {mounted && wishlist.length > 0 ? (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {wishlist.map((item) => {
            const price = item.salePrice ?? item.price;
            return (
              <div
                key={item.id}
                className="overflow-hidden rounded-2xl bg-white ring-1 ring-slate-100 transition hover:shadow-lg hover:shadow-slate-200"
              >
                <Link
                  href={`/product/${item.slug}`}
                  className="block aspect-[16/10] overflow-hidden bg-slate-50"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                </Link>
                <div className="p-4">
                  <span className="text-[10px] font-bold uppercase tracking-wide text-slate-400">
                    {item.category}
                  </span>
                  <Link
                    href={`/product/${item.slug}`}
                    className="mt-0.5 block text-[15px] font-bold text-slate-900 hover:text-orange-600"
                  >
                    {item.name}
                  </Link>
                  <div className="mt-1.5 flex items-baseline gap-1.5">
                    {item.salePrice && (
                      <span className="text-[12px] font-semibold text-slate-400 line-through">
                        {taka(item.price)}
                      </span>
                    )}
                    <span className="text-lg font-extrabold text-blue-600">{taka(price)}</span>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <button
                      onClick={() =>
                        item.stock > 0 &&
                        addToCart({
                          id: item.id,
                          slug: item.slug,
                          name: item.name,
                          image: item.image,
                          price,
                          variant: "",
                        })
                      }
                      disabled={item.stock <= 0}
                      className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-navy-900 py-2.5 text-[13px] font-bold text-white transition hover:bg-navy-800 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-400"
                    >
                      <ShoppingCart size={14} />
                      {item.stock > 0 ? "Add to Cart" : "Out of Stock"}
                    </button>
                    <button
                      onClick={() => toggleWishlist(item)}
                      className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 text-slate-400 transition hover:border-red-200 hover:text-red-500"
                      aria-label="Remove from wishlist"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="mt-8 rounded-2xl bg-white px-6 py-16 text-center shadow-sm ring-1 ring-slate-100">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-rose-50 text-rose-200">
            <Heart size={28} />
          </span>
          <h2 className="mt-5 text-2xl font-extrabold tracking-tight text-slate-800">
            Your wishlist is empty
          </h2>
          <p className="mt-2 text-sm text-slate-500">
            Save products to your wishlist to review them later.
          </p>
          <Link
            href="/shop"
            className="mt-7 inline-block rounded-full bg-navy-900 px-8 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
          >
            Go to Shop
          </Link>
        </div>
      )}
    </div>
  );
}
