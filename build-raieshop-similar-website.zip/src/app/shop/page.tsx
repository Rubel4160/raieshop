import Link from "next/link";
import { Suspense } from "react";
import { ChevronLeft, ChevronRight, Package } from "lucide-react";
import {
  getCategories,
  getShopProducts,
  getSubcategories,
} from "@/lib/data";
import ShopFilters from "@/components/store/ShopFilters";
import { ShopProductCard } from "@/components/store/ProductCards";

export const metadata = { title: "Shop" };

type SearchParams = Promise<{
  search?: string;
  category?: string;
  sub?: string;
  page?: string;
}>;

export default async function ShopPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const [categories, subcategories, result] = await Promise.all([
    getCategories(),
    getSubcategories(),
    getShopProducts({
      search: sp.search,
      category: sp.category,
      sub: sp.sub,
      page,
      pageSize: 12,
    }),
  ]);

  const buildUrl = (p: number) => {
    const params = new URLSearchParams();
    if (sp.search) params.set("search", sp.search);
    if (sp.category) params.set("category", sp.category);
    if (sp.sub) params.set("sub", sp.sub);
    if (p > 1) params.set("page", String(p));
    return `/shop${params.size ? `?${params.toString()}` : ""}`;
  };

  return (
    <div>
      {/* page head */}
      <div className="bg-gradient-to-b from-amber-50/80 via-[#f4f5fa] to-[#f4f5fa] pb-8 pt-12 text-center">
        <span className="rounded-full border border-amber-200 bg-amber-50 px-4 py-1.5 text-[10.5px] font-black uppercase tracking-[0.2em] text-amber-600">
          Curated Storefront
        </span>
        <h1 className="mt-4 text-3xl font-black tracking-tight text-slate-900 sm:text-[2.6rem]">
          Our Premium Collection
        </h1>
        <p className="mt-2 text-sm text-slate-500">
          Discover quality products for your lifestyle and daily needs.
        </p>
      </div>

      <div className="mx-auto max-w-7xl px-4 pb-16">
        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <Suspense fallback={<div className="h-96 rounded-2xl bg-white ring-1 ring-slate-100" />}>
            <ShopFilters
              categories={categories.map((c) => ({ name: c.name, slug: c.slug }))}
              subcategories={subcategories.map((s) => ({
                name: s.name,
                slug: s.slug,
                categorySlug:
                  categories.find((c) => c.id === s.categoryId)?.slug ?? "",
              }))}
            />
          </Suspense>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900">
                  Shop Products
                </h2>
                <p className="text-[12px] text-slate-500">
                  {result.total} items available
                </p>
              </div>
              <div className="flex flex-wrap gap-2 rounded-full bg-white px-4 py-2 text-[11px] font-semibold text-slate-500 ring-1 ring-slate-100">
                <span>Curated picks</span>
                <span className="text-slate-300">•</span>
                <span>Fast shopping</span>
                <span className="text-slate-300">•</span>
                <span>Secure checkout</span>
              </div>
            </div>

            {result.items.length === 0 ? (
              <div className="mt-8 flex flex-col items-center justify-center rounded-2xl bg-white py-20 text-center ring-1 ring-slate-100">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-50 text-slate-300">
                  <Package size={26} />
                </span>
                <h3 className="mt-4 text-lg font-extrabold text-slate-800">
                  No products found
                </h3>
                <p className="mt-1 text-sm text-slate-500">
                  Try a different search or reset the filters.
                </p>
                <Link
                  href="/shop"
                  className="mt-5 rounded-full bg-navy-900 px-6 py-2.5 text-sm font-bold text-white"
                >
                  Reset Filters
                </Link>
              </div>
            ) : (
              <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {result.items.map((p) => (
                  <ShopProductCard key={p.id} product={p} />
                ))}
              </div>
            )}

            {/* pagination */}
            {result.totalPages > 1 && (
              <div className="mt-10 flex items-center justify-center gap-4">
                {result.page > 1 ? (
                  <Link
                    href={buildUrl(result.page - 1)}
                    className="flex items-center gap-1 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-600 transition hover:border-navy-900 hover:text-navy-900"
                  >
                    <ChevronLeft size={15} />
                    Previous
                  </Link>
                ) : (
                  <span className="flex cursor-not-allowed items-center gap-1 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-300">
                    <ChevronLeft size={15} />
                    Previous
                  </span>
                )}
                <span className="text-sm font-bold text-slate-600">
                  Page {result.page} of {result.totalPages}
                </span>
                {result.page < result.totalPages ? (
                  <Link
                    href={buildUrl(result.page + 1)}
                    className="flex items-center gap-1 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-600 transition hover:border-navy-900 hover:text-navy-900"
                  >
                    Next
                    <ChevronRight size={15} />
                  </Link>
                ) : (
                  <span className="flex cursor-not-allowed items-center gap-1 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-bold text-slate-300">
                    Next
                    <ChevronRight size={15} />
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
