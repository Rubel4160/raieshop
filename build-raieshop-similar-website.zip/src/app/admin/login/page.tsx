import { redirect } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { isAdmin } from "@/lib/admin";
import { adminLogin } from "../actions";

export const metadata = { title: "Admin Login" };
export const dynamic = "force-dynamic";

export default async function AdminLoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  if (await isAdmin()) redirect("/admin");
  const sp = await searchParams;

  return (
    <div className="flex min-h-screen items-center justify-center bg-navy-900 px-4">
      <div className="w-full max-w-sm rounded-3xl bg-white p-8 shadow-2xl">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white shadow-lg shadow-fuchsia-900/30">
          <ShieldCheck size={26} />
        </span>
        <h1 className="mt-5 text-center text-2xl font-black tracking-tight text-slate-900">
          RAIESHOP <span className="text-orange-500">Admin</span>
        </h1>
        <p className="mt-1.5 text-center text-[13px] text-slate-500">
          Sign in to manage products, orders and your store.
        </p>

        {sp.error && (
          <p className="mt-4 rounded-xl bg-red-50 px-4 py-2.5 text-center text-[12.5px] font-semibold text-red-600">
            Wrong password. Please try again.
          </p>
        )}

        <form action={adminLogin} className="mt-6 space-y-4">
          <div>
            <label className="mb-1.5 block text-[12.5px] font-bold text-slate-700">
              Admin Password
            </label>
            <input
              type="password"
              name="password"
              required
              autoFocus
              placeholder="Enter admin password"
              className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none transition focus:border-navy-900 focus:ring-2 focus:ring-slate-100"
            />
          </div>
          <button className="w-full rounded-full bg-navy-900 py-3 text-sm font-bold text-white transition hover:bg-navy-800">
            Login to Dashboard
          </button>
        </form>

        <p className="mt-5 rounded-xl bg-slate-50 px-4 py-3 text-center text-[11.5px] leading-relaxed text-slate-400">
          Default password: <b className="text-slate-600">raieshop123</b>
          <br />
          Change it via <b className="text-slate-600">ADMIN_PASSWORD</b> in the .env file.
        </p>
      </div>
    </div>
  );
}
