import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { Pencil, Plus } from "lucide-react";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { taka } from "@/lib/site";
import DeleteButton from "./DeleteButton";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin - Products" };

export default async function AdminProductsPage() {
  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      image: products.image,
      price: products.price,
      salePrice: products.salePrice,
      stock: products.stock,
      isFeatured: products.isFeatured,
      isFlashSale: products.isFlashSale,
      isBestSeller: products.isBestSeller,
      category: categories.name,
    })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .orderBy(asc(products.id));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900">Products</h1>
          <p className="text-[13px] text-slate-500">{rows.length} products in your store.</p>
        </div>
        <Link
          href="/admin/products/new"
          className="flex items-center gap-1.5 rounded-full bg-orange-500 px-5 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600"
        >
          <Plus size={15} />
          Add Product
        </Link>
      </div>

      <div className="rounded-2xl bg-white ring-1 ring-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-left text-[13px]">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] uppercase tracking-wider text-slate-400">
                <th className="px-5 py-3.5 font-bold">Product</th>
                <th className="px-4 py-3.5 font-bold">Category</th>
                <th className="px-4 py-3.5 font-bold">Price</th>
                <th className="px-4 py-3.5 font-bold">Stock</th>
                <th className="px-4 py-3.5 font-bold">Tags</th>
                <th className="px-5 py-3.5 text-right font-bold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => (
                <tr key={p.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={p.image} alt={p.name} className="h-11 w-11 rounded-lg object-cover ring-1 ring-slate-200" />
                      <div>
                        <Link href={`/product/${p.slug}`} target="_blank" className="font-bold text-slate-800 hover:text-orange-600">
                          {p.name}
                        </Link>
                        <p className="text-[11px] text-slate-400">/{p.slug}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{p.category}</td>
                  <td className="px-4 py-3">
                    {p.salePrice ? (
                      <span>
                        <span className="mr-1.5 text-[11.5px] text-slate-400 line-through">{taka(p.price)}</span>
                        <span className="font-bold text-red-600">{taka(p.salePrice)}</span>
                      </span>
                    ) : (
                      <span className="font-bold text-slate-800">{taka(p.price)}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`font-bold ${p.stock > 0 ? "text-emerald-600" : "text-red-500"}`}>
                      {p.stock > 0 ? `${p.stock} pcs` : "Out"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {p.isFeatured && (
                        <span className="rounded-full bg-navy-900 px-2 py-0.5 text-[10px] font-bold text-white">Featured</span>
                      )}
                      {p.isFlashSale && (
                        <span className="rounded-full bg-red-500 px-2 py-0.5 text-[10px] font-bold text-white">Flash</span>
                      )}
                      {p.isBestSeller && (
                        <span className="rounded-full bg-violet-500 px-2 py-0.5 text-[10px] font-bold text-white">Best</span>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Link
                        href={`/admin/products/${p.id}`}
                        className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[12px] font-bold text-blue-600 transition hover:bg-blue-50"
                      >
                        <Pencil size={14} />
                        Edit
                      </Link>
                      <DeleteButton id={p.id} name={p.name} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
