import { getCategories, getSubcategories } from "@/lib/data";
import ProductForm from "../ProductForm";
import { PRODUCT_IMAGES } from "../images";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin - New Product" };

export default async function NewProductPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const sp = await searchParams;
  const [cats, subs] = await Promise.all([getCategories(), getSubcategories()]);

  return (
    <div>
      <h1 className="text-2xl font-black tracking-tight text-slate-900">Add Product</h1>
      <p className="mb-5 mt-1 text-[13px] text-slate-500">
        Create a new product for your store.
      </p>
      <ProductForm
        categories={cats.map((c) => ({ id: c.id, name: c.name }))}
        subcategories={subs.map((s) => ({ id: s.id, name: s.name, categoryId: s.categoryId }))}
        images={PRODUCT_IMAGES}
        error={sp.error}
      />
    </div>
  );
}
