"use client";

import { Trash2 } from "lucide-react";
import { deleteProduct } from "../../actions";

export default function DeleteButton({
  id,
  name,
}: {
  id: number;
  name: string;
}) {
  return (
    <form
      action={deleteProduct}
      onSubmit={(e) => {
        if (!confirm(`Delete "${name}"? This cannot be undone.`)) {
          e.preventDefault();
        }
      }}
    >
      <input type="hidden" name="id" value={id} />
      <button
        className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[12px] font-bold text-red-500 transition hover:bg-red-50"
        title="Delete product"
      >
        <Trash2 size={14} />
        Delete
      </button>
    </form>
  );
}
