"use client";

import { useState } from "react";
import Link from "next/link";
import { saveProduct } from "../../actions";

type Cat = { id: number; name: string };
type Sub = { id: number; name: string; categoryId: number };

export type EditableProduct = {
  id: number;
  name: string;
  slug: string;
  description: string;
  image: string;
  price: number;
  salePrice: number | null;
  stock: number;
  categoryId: number;
  subcategoryId: number | null;
  hasOptions: boolean;
  sizes: string;
  colors: string;
  isFeatured: boolean;
  isFlashSale: boolean;
  isBestSeller: boolean;
};

const inputCls =
  "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm outline-none transition focus:border-navy-900 focus:ring-2 focus:ring-slate-100";
const labelCls = "mb-1.5 block text-[12.5px] font-bold text-slate-700";

function Check({
  name,
  label,
  hint,
  defaultChecked,
}: {
  name: string;
  label: string;
  hint: string;
  defaultChecked?: boolean;
}) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-3.5 transition hover:border-slate-300 has-checked:border-orange-400 has-checked:bg-orange-50/50">
      <input
        type="checkbox"
        name={name}
        defaultChecked={defaultChecked}
        className="mt-0.5 h-4 w-4 accent-orange-500"
      />
      <span>
        <span className="block text-[13px] font-bold text-slate-800">{label}</span>
        <span className="block text-[11px] text-slate-400">{hint}</span>
      </span>
    </label>
  );
}

export default function ProductForm({
  categories,
  subcategories,
  images,
  product,
  error,
}: {
  categories: Cat[];
  subcategories: Sub[];
  images: string[];
  product?: EditableProduct;
  error?: string | null;
}) {
  const [categoryId, setCategoryId] = useState<number>(
    product?.categoryId ?? categories[0]?.id ?? 0
  );
  const [image, setImage] = useState<string>(product?.image ?? images[0]);
  const subs = subcategories.filter((s) => s.categoryId === categoryId);

  return (
    <form action={saveProduct} className="space-y-5">
      {product && <input type="hidden" name="id" value={product.id} />}
      {error && (
        <p className="rounded-xl bg-red-50 px-4 py-3 text-[13px] font-semibold text-red-600 ring-1 ring-red-100">
          Please fill all required fields (name, price, category, image).
        </p>
      )}

      <div className="grid gap-5 rounded-2xl bg-white p-6 ring-1 ring-slate-200 sm:grid-cols-2">
        {/* basic */}
        <div>
          <label className={labelCls}>Product Name *</label>
          <input name="name" required defaultValue={product?.name} placeholder="e.g. Gold Necklace" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Slug (URL)</label>
          <input name="slug" defaultValue={product?.slug} placeholder="auto-generated from name" className={inputCls} />
        </div>
        <div className="sm:col-span-2">
          <label className={labelCls}>Description</label>
          <textarea name="description" rows={3} defaultValue={product?.description} placeholder="Short product description" className={inputCls} />
        </div>

        {/* pricing */}
        <div>
          <label className={labelCls}>Price (৳) *</label>
          <input name="price" type="number" min={0} required defaultValue={product?.price} placeholder="5000" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Sale Price (৳) — optional</label>
          <input name="salePrice" type="number" min={0} defaultValue={product?.salePrice ?? ""} placeholder="4500" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Stock Quantity *</label>
          <input name="stock" type="number" min={0} required defaultValue={product?.stock ?? 10} className={inputCls} />
        </div>

        {/* image */}
        <div>
          <label className={labelCls}>Product Image *</label>
          <select name="image" value={image} onChange={(e) => setImage(e.target.value)} className={inputCls}>
            {images.map((img) => (
              <option key={img} value={img}>
                {img.replace("/images/products/", "")}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2 flex items-center gap-4 rounded-xl bg-slate-50 p-4 ring-1 ring-slate-100">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt="Preview" className="h-20 w-20 rounded-xl object-cover ring-1 ring-slate-200" />
          <div className="min-w-0">
            <p className="text-[12px] font-bold text-slate-700">Image Preview</p>
            <p className="truncate text-[11px] text-slate-400">{image}</p>
            <p className="mt-1 text-[11px] text-slate-400">
              New images can be added inside the <b>public/images/products</b> folder.
            </p>
          </div>
        </div>

        {/* category */}
        <div>
          <label className={labelCls}>Category *</label>
          <select
            name="categoryId"
            value={categoryId}
            onChange={(e) => setCategoryId(Number(e.target.value))}
            className={inputCls}
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className={labelCls}>Subcategory</label>
          <select name="subcategoryId" defaultValue={product?.subcategoryId ?? ""} className={inputCls} key={categoryId}>
            <option value="">None</option>
            {subs.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>

        {/* options */}
        <div>
          <label className={labelCls}>Sizes (comma separated)</label>
          <input name="sizes" defaultValue={product?.sizes} placeholder="S,M,L,XL" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Colors (comma separated)</label>
          <input name="colors" defaultValue={product?.colors} placeholder="Black,White" className={inputCls} />
        </div>
      </div>

      {/* flags */}
      <div className="grid gap-3 rounded-2xl bg-white p-6 ring-1 ring-slate-200 sm:grid-cols-2">
        <Check name="hasOptions" label="Has Options" hint="Customer must pick size/color on the product page" defaultChecked={product?.hasOptions} />
        <Check name="isFeatured" label="Featured" hint="Show in homepage trending & lifestyle sections" defaultChecked={product?.isFeatured} />
        <Check name="isFlashSale" label="Flash Sale" hint="Show on the Flash Sale page & homepage deals" defaultChecked={product?.isFlashSale} />
        <Check name="isBestSeller" label="Best Seller" hint="Show in the Best Sellers section" defaultChecked={product?.isBestSeller} />
      </div>

      <div className="flex items-center gap-3">
        <button className="rounded-full bg-navy-900 px-8 py-3 text-sm font-bold text-white transition hover:bg-navy-800">
          {product ? "Save Changes" : "Create Product"}
        </button>
        <Link
          href="/admin/products"
          className="rounded-full border border-slate-300 px-8 py-3 text-sm font-bold text-slate-600 transition hover:border-slate-400"
        >
          Cancel
        </Link>
      </div>
    </form>
  );
}
