import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { getCategories, getSubcategories } from "@/lib/data";
import ProductForm from "../ProductForm";
import { PRODUCT_IMAGES } from "../images";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin - Edit Product" };

type Params = Promise<{ id: string }>;

export default async function EditProductPage({
  params,
  searchParams,
}: {
  params: Params;
  searchParams: Promise<{ error?: string }>;
}) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const productId = parseInt(id, 10);
  if (!productId) notFound();

  const [rows, cats, subs] = await Promise.all([
    db.select().from(products).where(eq(products.id, productId)).limit(1),
    getCategories(),
    getSubcategories(),
  ]);
  const product = rows[0];
  if (!product) notFound();

  const images = product.image && !PRODUCT_IMAGES.includes(product.image)
    ? [product.image, ...PRODUCT_IMAGES]
    : PRODUCT_IMAGES;

  return (
    <div>
      <h1 className="text-2xl font-black tracking-tight text-slate-900">
        Edit: {product.name}
      </h1>
      <p className="mb-5 mt-1 text-[13px] text-slate-500">
        Update pricing, stock, categories and storefront placement.
      </p>
      <ProductForm
        categories={cats.map((c) => ({ id: c.id, name: c.name }))}
        subcategories={subs.map((s) => ({ id: s.id, name: s.name, categoryId: s.categoryId }))}
        images={images}
        product={product}
        error={sp.error}
      />
    </div>
  );
}
