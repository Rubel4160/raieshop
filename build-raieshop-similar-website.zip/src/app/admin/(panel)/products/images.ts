export const PRODUCT_IMAGES = [
  "/images/products/jewellery.jpg",
  "/images/products/fashion.jpg",
  "/images/products/bags.jpg",
  "/images/products/kitchen.jpg",
  "/images/products/electronics.jpg",
  "/images/products/headphone.jpg",
  "/images/products/pan.jpg",
  "/images/products/tv.jpg",
  "/images/products/dress.jpg",
  "/images/products/accessories.jpg",
];
