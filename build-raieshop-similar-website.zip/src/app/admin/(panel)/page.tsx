import Link from "next/link";
import { desc, ne, sql } from "drizzle-orm";
import {
  Banknote,
  ClipboardList,
  MailPlus,
  Package,
  Truck,
  Users,
} from "lucide-react";
import { db } from "@/db";
import { newsletterSubscribers, orders, products, users } from "@/db/schema";
import { taka } from "@/lib/site";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin Dashboard" };

const statusBadge: Record<string, string> = {
  processing: "bg-amber-50 text-amber-600 ring-amber-100",
  shipped: "bg-blue-50 text-blue-600 ring-blue-100",
  delivered: "bg-emerald-50 text-emerald-600 ring-emerald-100",
  cancelled: "bg-red-50 text-red-500 ring-red-100",
};

export default async function AdminDashboard() {
  const [[p], [o], [r], [s], [u], [active], recent] = await Promise.all([
    db.select({ n: sql<number>`count(*)::int` }).from(products),
    db.select({ n: sql<number>`count(*)::int` }).from(orders),
    db
      .select({ n: sql<number>`coalesce(sum(${orders.total}), 0)::int` })
      .from(orders)
      .where(ne(orders.status, "cancelled")),
    db.select({ n: sql<number>`count(*)::int` }).from(newsletterSubscribers),
    db.select({ n: sql<number>`count(*)::int` }).from(users),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(orders)
      .where(ne(orders.status, "delivered"))
      .then((rows) => rows),
    db.select().from(orders).orderBy(desc(orders.id)).limit(6),
  ]);

  const stats = [
    { label: "Total Products", value: String(p.n), icon: Package, tone: "text-violet-500 bg-violet-50" },
    { label: "Total Orders", value: String(o.n), icon: ClipboardList, tone: "text-blue-500 bg-blue-50" },
    { label: "Active Orders", value: String(active.n), icon: Truck, tone: "text-amber-500 bg-amber-50" },
    { label: "Revenue", value: taka(r.n), icon: Banknote, tone: "text-emerald-500 bg-emerald-50" },
    { label: "Customers", value: String(u.n), icon: Users, tone: "text-pink-500 bg-pink-50" },
    { label: "Subscribers", value: String(s.n), icon: MailPlus, tone: "text-sky-500 bg-sky-50" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900">
            Dashboard
          </h1>
          <p className="text-[13px] text-slate-500">
            Overview of your RAIESHOP store.
          </p>
        </div>
        <Link
          href="/admin/products/new"
          className="rounded-full bg-orange-500 px-5 py-2.5 text-[13px] font-bold text-white shadow-lg shadow-orange-500/30 transition hover:bg-orange-600"
        >
          + Add Product
        </Link>
      </div>

      {/* stats */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl bg-white p-4 ring-1 ring-slate-200">
            <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${s.tone}`}>
              <s.icon size={17} />
            </span>
            <p className="mt-3 truncate text-lg font-black text-slate-900">{s.value}</p>
            <p className="text-[11.5px] font-semibold text-slate-400">{s.label}</p>
          </div>
        ))}
      </div>

      {/* recent orders */}
      <div className="rounded-2xl bg-white ring-1 ring-slate-200">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h2 className="text-[15px] font-extrabold text-slate-900">Recent Orders</h2>
          <Link href="/admin/orders" className="text-[12.5px] font-bold text-orange-500 hover:text-orange-600">
            View All →
          </Link>
        </div>
        {recent.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-slate-400">
            No orders yet. Orders will appear here once customers start shopping.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-[13px]">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] uppercase tracking-wider text-slate-400">
                  <th className="px-5 py-3 font-bold">Order</th>
                  <th className="px-5 py-3 font-bold">Customer</th>
                  <th className="px-5 py-3 font-bold">Total</th>
                  <th className="px-5 py-3 font-bold">Status</th>
                  <th className="px-5 py-3 font-bold"></th>
                </tr>
              </thead>
              <tbody>
                {recent.map((o) => (
                  <tr key={o.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-bold text-slate-800">{o.orderNumber}</td>
                    <td className="px-5 py-3 text-slate-600">
                      {o.customerName}
                      <span className="block text-[11px] text-slate-400">{o.phone}</span>
                    </td>
                    <td className="px-5 py-3 font-bold text-slate-800">{taka(o.total)}</td>
                    <td className="px-5 py-3">
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ring-1 ${statusBadge[o.status] ?? "bg-slate-50 text-slate-500 ring-slate-100"}`}>
                        {o.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link href={`/admin/orders/${o.id}`} className="font-bold text-blue-600 hover:underline">
                        Details
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
