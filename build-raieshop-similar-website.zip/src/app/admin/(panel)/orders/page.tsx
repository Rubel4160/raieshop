import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { taka } from "@/lib/site";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin - Orders" };

const statusBadge: Record<string, string> = {
  processing: "bg-amber-50 text-amber-600 ring-amber-100",
  shipped: "bg-blue-50 text-blue-600 ring-blue-100",
  delivered: "bg-emerald-50 text-emerald-600 ring-emerald-100",
  cancelled: "bg-red-50 text-red-500 ring-red-100",
};

export default async function AdminOrdersPage() {
  const rows = await db.select().from(orders).orderBy(desc(orders.id)).limit(100);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-black tracking-tight text-slate-900">Orders</h1>
        <p className="text-[13px] text-slate-500">
          {rows.length} orders — newest first.
        </p>
      </div>

      <div className="rounded-2xl bg-white ring-1 ring-slate-200">
        {rows.length === 0 ? (
          <p className="px-5 py-14 text-center text-sm text-slate-400">
            No orders yet. When customers place orders, they will show up here.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-[13px]">
              <thead>
                <tr className="border-b border-slate-100 text-[11px] uppercase tracking-wider text-slate-400">
                  <th className="px-5 py-3.5 font-bold">Order Number</th>
                  <th className="px-4 py-3.5 font-bold">Customer</th>
                  <th className="px-4 py-3.5 font-bold">Payment</th>
                  <th className="px-4 py-3.5 font-bold">Total</th>
                  <th className="px-4 py-3.5 font-bold">Date</th>
                  <th className="px-4 py-3.5 font-bold">Status</th>
                  <th className="px-5 py-3.5 text-right font-bold"></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((o) => (
                  <tr key={o.id} className="border-b border-slate-50 last:border-0 hover:bg-slate-50/60">
                    <td className="px-5 py-3 font-bold text-slate-800">{o.orderNumber}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {o.customerName}
                      <span className="block text-[11px] text-slate-400">{o.phone}</span>
                    </td>
                    <td className="px-4 py-3 uppercase text-slate-500">{o.paymentMethod}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">{taka(o.total)}</td>
                    <td className="px-4 py-3 text-slate-500">
                      {new Date(o.createdAt).toLocaleDateString("en-GB", {
                        day: "numeric",
                        month: "short",
                      })}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold capitalize ring-1 ${statusBadge[o.status] ?? "bg-slate-50 text-slate-500 ring-slate-100"}`}>
                        {o.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link href={`/admin/orders/${o.id}`} className="font-bold text-blue-600 hover:underline">
                        Manage
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
