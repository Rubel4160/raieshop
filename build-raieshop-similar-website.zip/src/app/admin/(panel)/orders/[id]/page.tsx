import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { ArrowLeft } from "lucide-react";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { taka } from "@/lib/site";
import { updateOrderStatus } from "../../../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin - Order Details" };

type Params = Promise<{ id: string }>;

const STATUSES = ["processing", "shipped", "delivered", "cancelled"] as const;

const statusBadge: Record<string, string> = {
  processing: "bg-amber-50 text-amber-600 ring-amber-100",
  shipped: "bg-blue-50 text-blue-600 ring-blue-100",
  delivered: "bg-emerald-50 text-emerald-600 ring-emerald-100",
  cancelled: "bg-red-50 text-red-500 ring-red-100",
};

export default async function AdminOrderDetailPage({ params }: { params: Params }) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (!orderId) notFound();

  const rows = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  const order = rows[0];
  if (!order) notFound();

  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderId, order.id));

  return (
    <div className="space-y-5">
      <Link
        href="/admin/orders"
        className="inline-flex items-center gap-1.5 text-[13px] font-bold text-slate-500 hover:text-navy-900"
      >
        <ArrowLeft size={14} />
        Back to Orders
      </Link>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-slate-900">
            {order.orderNumber}
          </h1>
          <p className="text-[13px] text-slate-500">
            Placed on{" "}
            {new Date(order.createdAt).toLocaleString("en-GB", {
              day: "numeric",
              month: "long",
              year: "numeric",
              hour: "numeric",
              minute: "2-digit",
            })}
          </p>
        </div>
        <span className={`rounded-full px-4 py-1.5 text-[12.5px] font-bold capitalize ring-1 ${statusBadge[order.status] ?? "bg-slate-50 text-slate-500 ring-slate-100"}`}>
          {order.status}
        </span>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        {/* items */}
        <div className="space-y-5">
          <div className="rounded-2xl bg-white ring-1 ring-slate-200">
            <h2 className="border-b border-slate-100 px-5 py-4 text-[15px] font-extrabold text-slate-900">
              Ordered Items
            </h2>
            {items.map((i) => (
              <div key={i.id} className="flex items-center justify-between border-b border-slate-50 px-5 py-3.5 last:border-0">
                <div>
                  <Link href={`/product/${i.productSlug}`} target="_blank" className="text-[13.5px] font-bold text-slate-800 hover:text-orange-600">
                    {i.productName}
                  </Link>
                  <p className="text-[11.5px] text-slate-400">
                    {i.variant ? `${i.variant} • ` : ""}Qty {i.quantity} × {taka(i.unitPrice)}
                  </p>
                </div>
                <span className="text-[13.5px] font-bold text-slate-800">
                  {taka(i.unitPrice * i.quantity)}
                </span>
              </div>
            ))}
            <div className="space-y-1.5 bg-slate-50 px-5 py-4 text-[13px]">
              <div className="flex justify-between text-slate-500">
                <span>Subtotal</span>
                <span>{taka(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Delivery ({order.deliveryArea === "inside" ? "Inside Dhaka" : "Outside Dhaka"})</span>
                <span>{order.deliveryCharge === 0 ? "FREE" : taka(order.deliveryCharge)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2 font-black text-slate-900">
                <span>Total</span>
                <span>{taka(order.total)}</span>
              </div>
            </div>
          </div>

          <div className="rounded-2xl bg-white p-5 ring-1 ring-slate-200">
            <h2 className="text-[15px] font-extrabold text-slate-900">Customer Details</h2>
            <div className="mt-3 grid gap-2 text-[13px] text-slate-600 sm:grid-cols-2">
              <p><span className="font-bold text-slate-800">Name:</span> {order.customerName}</p>
              <p><span className="font-bold text-slate-800">Phone:</span> {order.phone}</p>
              <p className="sm:col-span-2"><span className="font-bold text-slate-800">Address:</span> {order.address}</p>
              <p><span className="font-bold text-slate-800">Payment:</span> <span className="uppercase">{order.paymentMethod}</span></p>
              {order.note && (
                <p><span className="font-bold text-slate-800">Note:</span> {order.note}</p>
              )}
            </div>
          </div>
        </div>

        {/* status update */}
        <aside className="h-fit rounded-2xl bg-white p-5 ring-1 ring-slate-200 lg:sticky lg:top-6">
          <h2 className="text-[15px] font-extrabold text-slate-900">Update Status</h2>
          <p className="mt-1 text-[12px] text-slate-400">
            Customers can see this status in Track Order.
          </p>
          <form action={updateOrderStatus} className="mt-4 space-y-3">
            <input type="hidden" name="id" value={order.id} />
            <select
              name="status"
              defaultValue={order.status}
              className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm font-semibold capitalize outline-none focus:border-navy-900"
            >
              {STATUSES.map((s) => (
                <option key={s} value={s} className="capitalize">
                  {s}
                </option>
              ))}
            </select>
            <button className="w-full rounded-full bg-navy-900 py-2.5 text-sm font-bold text-white transition hover:bg-navy-800">
              Save Status
            </button>
          </form>

          <div className="mt-5 space-y-2 rounded-xl bg-slate-50 p-4 text-[11.5px] leading-relaxed text-slate-500">
            <p className="font-bold text-slate-700">Flow suggestion</p>
            <p>1. Confirm order by calling the customer</p>
            <p>2. Mark as <b>shipped</b> when handed to courier</p>
            <p>3. Mark as <b>delivered</b> after payment received</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
