"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ClipboardList, LayoutDashboard, Package } from "lucide-react";

const links = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/admin/products", label: "Products", icon: Package, exact: false },
  { href: "/admin/orders", label: "Orders", icon: ClipboardList, exact: false },
];

export default function AdminNav() {
  const pathname = usePathname();
  return (
    <aside className="flex shrink-0 gap-2 lg:w-52 lg:flex-col">
      {links.map((l) => {
        const active = l.exact
          ? pathname === l.href
          : pathname === l.href || pathname.startsWith(`${l.href}/`);
        return (
          <Link
            key={l.href}
            href={l.href}
            className={`flex items-center gap-2.5 rounded-xl px-4 py-2.5 text-[13.5px] font-bold transition ${
              active
                ? "bg-navy-900 text-white shadow-md"
                : "bg-white text-slate-600 ring-1 ring-slate-200 hover:text-navy-900"
            }`}
          >
            <l.icon size={16} />
            {l.label}
          </Link>
        );
      })}
    </aside>
  );
}
