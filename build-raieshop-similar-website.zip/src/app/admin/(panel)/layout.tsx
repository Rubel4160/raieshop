import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { ExternalLink, LogOut } from "lucide-react";
import { isAdmin } from "@/lib/admin";
import { adminLogout } from "../actions";
import AdminNav from "./AdminNav";

export const dynamic = "force-dynamic";

export default async function AdminPanelLayout({
  children,
}: {
  children: ReactNode;
}) {
  if (!(await isAdmin())) redirect("/admin/login");

  return (
    <div className="min-h-screen bg-slate-100">
      {/* top bar */}
      <div className="bg-navy-900">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3.5">
          <Link href="/admin" className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-600 text-sm font-black text-white">
              RS
            </span>
            <span className="text-[15px] font-extrabold tracking-tight text-white">
              RAIESHOP <span className="text-orange-400">Admin</span>
            </span>
          </Link>
          <div className="flex items-center gap-2">
            <Link
              href="/"
              target="_blank"
              className="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[12.5px] font-semibold text-slate-300 transition hover:bg-white/10 hover:text-white"
            >
              <ExternalLink size={14} />
              View Store
            </Link>
            <form action={adminLogout}>
              <button className="flex items-center gap-1.5 rounded-full bg-white/10 px-3.5 py-2 text-[12.5px] font-semibold text-slate-200 transition hover:bg-red-500/80 hover:text-white">
                <LogOut size={14} />
                Logout
              </button>
            </form>
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 py-6 lg:flex-row">
        <AdminNav />
        <div className="min-w-0 flex-1">{children}</div>
      </div>
    </div>
  );
}
