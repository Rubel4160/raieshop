"use server";

import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, products } from "@/db/schema";
import {
  checkAdminPassword,
  clearAdminSession,
  isAdmin,
  setAdminSession,
} from "@/lib/admin";

export async function adminLogin(formData: FormData) {
  const password = String(formData.get("password") ?? "");
  if (!checkAdminPassword(password)) {
    redirect("/admin/login?error=1");
  }
  await setAdminSession();
  redirect("/admin");
}

export async function adminLogout() {
  await clearAdminSession();
  redirect("/admin/login");
}

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/'/g, "")
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export async function saveProduct(formData: FormData) {
  if (!(await isAdmin())) redirect("/admin/login");

  const idRaw = String(formData.get("id") ?? "").trim();
  const id = idRaw ? parseInt(idRaw, 10) : null;
  const errorUrl = id ? `/admin/products/${id}?error=1` : "/admin/products/new?error=1";

  const name = String(formData.get("name") ?? "").trim();
  let slug = String(formData.get("slug") ?? "").trim() || slugify(name);
  const description = String(formData.get("description") ?? "").trim();
  const image = String(formData.get("image") ?? "").trim();
  const price = Math.max(0, parseInt(String(formData.get("price") ?? "0"), 10) || 0);
  const salePriceRaw = String(formData.get("salePrice") ?? "").trim();
  const salePrice = salePriceRaw
    ? Math.max(0, parseInt(salePriceRaw, 10) || 0)
    : null;
  const stock = Math.max(0, parseInt(String(formData.get("stock") ?? "0"), 10) || 0);
  const categoryId = parseInt(String(formData.get("categoryId") ?? "0"), 10);
  const subRaw = String(formData.get("subcategoryId") ?? "").trim();
  const subcategoryId = subRaw ? parseInt(subRaw, 10) : null;

  if (!name || !price || !categoryId || !image) {
    redirect(errorUrl);
  }

  if (!id) {
    const dup = await db
      .select({ id: products.id })
      .from(products)
      .where(eq(products.slug, slug))
      .limit(1);
    if (dup[0]) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
  }

  const values = {
    name,
    slug,
    description,
    image,
    price,
    salePrice,
    stock,
    categoryId,
    subcategoryId,
    hasOptions: formData.get("hasOptions") === "on",
    sizes: String(formData.get("sizes") ?? "").trim(),
    colors: String(formData.get("colors") ?? "").trim(),
    isFeatured: formData.get("isFeatured") === "on",
    isFlashSale: formData.get("isFlashSale") === "on",
    isBestSeller: formData.get("isBestSeller") === "on",
  };

  if (id) {
    await db.update(products).set(values).where(eq(products.id, id));
  } else {
    await db.insert(products).values(values);
  }
  redirect("/admin/products");
}

export async function deleteProduct(formData: FormData) {
  if (!(await isAdmin())) redirect("/admin/login");
  const id = parseInt(String(formData.get("id") ?? "0"), 10);
  if (id) {
    await db.delete(products).where(eq(products.id, id));
  }
  redirect("/admin/products");
}

export async function updateOrderStatus(formData: FormData) {
  if (!(await isAdmin())) redirect("/admin/login");
  const id = parseInt(String(formData.get("id") ?? "0"), 10);
  const status = String(formData.get("status") ?? "processing");
  const allowed = ["processing", "shipped", "delivered", "cancelled"];
  if (id && allowed.includes(status)) {
    await db.update(orders).set({ status }).where(eq(orders.id, id));
  }
  redirect(`/admin/orders/${id}`);
}
