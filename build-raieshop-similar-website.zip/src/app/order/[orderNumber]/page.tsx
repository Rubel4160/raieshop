import Link from "next/link";
import { notFound } from "next/navigation";
import { CheckCircle2, PackageSearch, ShoppingBag } from "lucide-react";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { taka } from "@/lib/site";

export const metadata = { title: "Order Confirmed" };

type Params = Promise<{ orderNumber: string }>;

export default async function OrderSuccessPage({ params }: { params: Params }) {
  const { orderNumber } = await params;
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber))
    .limit(1);
  const order = rows[0];
  if (!order) notFound();

  const items = await db
    .select()
    .from(orderItems)
    .where(eq(orderItems.orderId, order.id));

  return (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <div className="rounded-3xl bg-white p-8 text-center ring-1 ring-slate-100 sm:p-12">
        <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-50 text-emerald-500 ring-8 ring-emerald-50/60">
          <CheckCircle2 size={38} />
        </span>
        <h1 className="mt-6 text-3xl font-black tracking-tight text-slate-900">
          Order Placed Successfully!
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-500">
          Thank you, <span className="font-bold text-slate-700">{order.customerName}</span>.
          Our team will call <span className="font-bold text-slate-700">{order.phone}</span> to
          confirm your order shortly.
        </p>

        <div className="mx-auto mt-6 max-w-sm rounded-2xl bg-slate-50 px-6 py-4 ring-1 ring-slate-100">
          <p className="text-[11px] font-black uppercase tracking-widest text-slate-400">
            Your Order Number
          </p>
          <p className="mt-1 text-xl font-black tracking-wide text-navy-900">
            {order.orderNumber}
          </p>
        </div>

        <div className="mx-auto mt-6 max-w-md text-left">
          <div className="rounded-2xl ring-1 ring-slate-100">
            {items.map((i) => (
              <div
                key={i.id}
                className="flex items-center justify-between border-b border-slate-100 px-5 py-3 last:border-0"
              >
                <div>
                  <p className="text-[13px] font-bold text-slate-800">{i.productName}</p>
                  <p className="text-[11px] text-slate-400">
                    {i.variant ? `${i.variant} • ` : ""}Qty {i.quantity}
                  </p>
                </div>
                <span className="text-[13px] font-bold text-slate-700">
                  {taka(i.unitPrice * i.quantity)}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between bg-slate-50 px-5 py-3">
              <span className="text-[13px] font-bold text-slate-900">
                Total ({order.paymentMethod === "cod" ? "Cash on Delivery" : order.paymentMethod})
              </span>
              <span className="text-[15px] font-black text-navy-900">{taka(order.total)}</span>
            </div>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/track-order"
            className="flex items-center gap-2 rounded-full bg-navy-900 px-7 py-3 text-sm font-bold text-white transition hover:bg-navy-800"
          >
            <PackageSearch size={16} />
            Track Order
          </Link>
          <Link
            href="/shop"
            className="flex items-center gap-2 rounded-full border border-slate-200 px-7 py-3 text-sm font-bold text-slate-700 transition hover:border-navy-900"
          >
            <ShoppingBag size={16} />
            Continue Shopping
          </Link>
        </div>
      </div>
    </div>
  );
}
