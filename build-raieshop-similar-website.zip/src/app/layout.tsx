import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { StoreProvider, Toast } from "@/context/StoreContext";
import Header from "@/components/store/Header";
import Footer from "@/components/store/Footer";
import SiteChrome from "@/components/store/SiteChrome";
import { getCategories, getSubcategories } from "@/lib/data";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "RAIESHOP - Premium Lifestyle Ecommerce",
    template: "%s | RAIESHOP",
  },
  description:
    "Discover fashion, jewellery, electronics, kitchen essentials and handpicked trending items in one place. Cash on delivery across Bangladesh.",
};

export default async function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  let navCats: { name: string; slug: string; subs: { name: string; slug: string }[] }[] = [];
  try {
    const [cats, subs] = await Promise.all([getCategories(), getSubcategories()]);
    navCats = cats.map((c) => ({
      name: c.name,
      slug: c.slug,
      subs: subs
        .filter((s) => s.categoryId === c.id)
        .map((s) => ({ name: s.name, slug: s.slug })),
    }));
  } catch {
    // DB not ready yet (e.g. fresh sandbox) — render nav without categories
    navCats = [];
  }

  return (
    <html lang="en" className={jakarta.variable}>
      <body className="bg-[#f4f5fa] font-sans text-slate-900 antialiased">
        <StoreProvider>
          <SiteChrome header={<Header categories={navCats} />} footer={<Footer />}>
            {children}
          </SiteChrome>
          <Toast />
        </StoreProvider>
      </body>
    </html>
  );
}
