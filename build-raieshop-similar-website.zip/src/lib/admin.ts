import crypto from "node:crypto";
import { cookies } from "next/headers";

const COOKIE = "raieshop_admin";
const PASSWORD = process.env.ADMIN_PASSWORD || "raieshop123";

function token(): string {
  return crypto
    .createHmac("sha256", `${PASSWORD}|raieshop-admin-salt`)
    .update("raieshop-admin-session")
    .digest("hex");
}

export function checkAdminPassword(pw: string): boolean {
  return pw.length > 0 && pw === PASSWORD;
}

export async function setAdminSession() {
  const jar = await cookies();
  jar.set(COOKIE, token(), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12, // 12 hours
  });
}

export async function clearAdminSession() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export async function isAdmin(): Promise<boolean> {
  const jar = await cookies();
  const value = jar.get(COOKIE)?.value;
  if (!value) return false;
  const expected = Buffer.from(token(), "utf8");
  const given = Buffer.from(value, "utf8");
  return expected.length === given.length && crypto.timingSafeEqual(expected, given);
}
