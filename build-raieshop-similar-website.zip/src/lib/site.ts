export const SITE = {
  name: "RAIESHOP",
  shortName: "RaieShop",
  tagline: "Built for premium ecommerce business launch.",
  phone: "+8801825124160",
  phoneRaw: "8801825124160",
  email: "support@raieshop.com",
  address: "Dhaka, Bangladesh",
  freeDeliveryOver: 2000,
  deliveryInside: 60,
  deliveryOutside: 120,
};

export const TICKER_ITEMS = [
  "Free delivery on orders over ৳2,000",
  "Cash on Delivery Available",
  "Manual bKash/Nagad Payment",
  "Fast Bangladesh Delivery",
  "WhatsApp: +8801825124160",
  "Messenger Support Available",
];

export function taka(amount: number): string {
  return `৳${amount.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function takaShort(amount: number): string {
  return `৳${amount.toLocaleString("en-US")}`;
}

export function discountPercent(price: number, salePrice: number | null): number {
  if (!salePrice || salePrice >= price) return 0;
  return Math.round(((price - salePrice) / price) * 100);
}
