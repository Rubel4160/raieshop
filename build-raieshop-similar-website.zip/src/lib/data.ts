import { db } from "@/db";
import {
  categories,
  subcategories,
  products,
  reviews,
  type Category,
  type Subcategory,
  type DbProduct,
} from "@/db/schema";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";

export type ProductCard = {
  id: number;
  name: string;
  slug: string;
  description: string;
  image: string;
  price: number;
  salePrice: number | null;
  stock: number;
  hasOptions: boolean;
  sizes: string;
  colors: string;
  isFeatured: boolean;
  isFlashSale: boolean;
  isBestSeller: boolean;
  category: string;
  categorySlug: string;
  subcategory: string | null;
  subcategorySlug: string | null;
};

const productSelection = {
  id: products.id,
  name: products.name,
  slug: products.slug,
  description: products.description,
  image: products.image,
  price: products.price,
  salePrice: products.salePrice,
  stock: products.stock,
  hasOptions: products.hasOptions,
  sizes: products.sizes,
  colors: products.colors,
  isFeatured: products.isFeatured,
  isFlashSale: products.isFlashSale,
  isBestSeller: products.isBestSeller,
  category: categories.name,
  categorySlug: categories.slug,
  subcategory: subcategories.name,
  subcategorySlug: subcategories.slug,
};

function baseProductQuery() {
  return db
    .select(productSelection)
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(subcategories, eq(products.subcategoryId, subcategories.id));
}

export async function getCategories(): Promise<Category[]> {
  return db.select().from(categories).orderBy(asc(categories.sortOrder));
}

export async function getSubcategories(): Promise<Subcategory[]> {
  return db.select().from(subcategories).orderBy(asc(subcategories.id));
}

export async function getAllProducts(): Promise<ProductCard[]> {
  return baseProductQuery().orderBy(asc(products.id));
}

export async function getFlashSaleProducts(): Promise<ProductCard[]> {
  return baseProductQuery()
    .where(eq(products.isFlashSale, true))
    .orderBy(asc(products.id));
}

export async function getBestSellers(): Promise<ProductCard[]> {
  return baseProductQuery()
    .where(eq(products.isBestSeller, true))
    .orderBy(asc(products.id));
}

export async function getFeaturedByCategory(): Promise<ProductCard[]> {
  return baseProductQuery()
    .where(eq(products.isFeatured, true))
    .orderBy(desc(products.stock));
}

export async function getProductBySlug(
  slug: string
): Promise<ProductCard | undefined> {
  const rows = await baseProductQuery().where(eq(products.slug, slug)).limit(1);
  return rows[0];
}

export async function getRelatedProducts(
  categorySlug: string,
  excludeId: number,
  limit = 4
): Promise<ProductCard[]> {
  const rows = await baseProductQuery()
    .where(
      and(eq(categories.slug, categorySlug), sql`${products.id} <> ${excludeId}`)
    )
    .orderBy(desc(products.stock))
    .limit(limit);
  return rows;
}

export type ShopFilters = {
  search?: string;
  category?: string;
  sub?: string;
  page?: number;
  pageSize?: number;
};

export async function getShopProducts(filters: ShopFilters): Promise<{
  items: ProductCard[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}> {
  const conds = [];
  if (filters.search) {
    const q = `%${filters.search}%`;
    conds.push(
      or(ilike(products.name, q), ilike(products.description, q), ilike(categories.name, q))
    );
  }
  if (filters.category) conds.push(eq(categories.slug, filters.category));
  if (filters.sub) conds.push(eq(subcategories.slug, filters.sub));

  const where = conds.length ? and(...conds) : undefined;
  const pageSize = filters.pageSize ?? 12;
  const page = Math.max(1, filters.page ?? 1);

  const countRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .innerJoin(categories, eq(products.categoryId, categories.id))
    .leftJoin(subcategories, eq(products.subcategoryId, subcategories.id))
    .where(where);

  const total = countRows[0]?.count ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const safePage = Math.min(page, totalPages);

  const items = await baseProductQuery()
    .where(where)
    .orderBy(asc(products.id))
    .limit(pageSize)
    .offset((safePage - 1) * pageSize);

  return { items, total, page: safePage, pageSize, totalPages };
}

export async function getReviews() {
  return db.select().from(reviews).orderBy(desc(reviews.id)).limit(5);
}
